---
title: "My experience in the open source world and boss"
date: "2018-12-11T21:32:41.000Z"
slug: "my-experience-in-the-open-source-world-and-boss-2"
image: "https://blog.codingblocks.com/content/images/2019/01/pexels-photo-943096.jpeg"
description: "Hi everyone, I am Pulkit Aggarwal, studying in Keshav Mahavidalaya,Delhi University.  i've doing android development for a past year but these 3 months most exciting one all thanks to BOSS,i came to know about BOSS from arnav bhaiya facebook post.I wasn't sure will i'll be able to"
tags: []
original_url: "https://blog.codingblocks.com/2018/my-experience-in-the-open-source-world-and-boss-2/"
---

Hi everyone, I am Pulkit Aggarwal, studying in Keshav Mahavidalaya,Delhi University.

i've doing android development for a past year but these 3 months most exciting one all thanks to BOSS,i came to know about BOSS from arnav bhaiya facebook post.I wasn't sure will i'll be able to compete against other developers but i as the time passes by i got to know that BOSS is more about learning how to participate in open source rather than competing against other developers.

## I am really thankful to Coding Blocks for their open source event BOSS. This really helped me get started with open source and i can see myself trying for BOSS as well GSOC next year and hopefully getting accepted for both.

![121212_2_OpenSwissKnife-1](https://blog.codingblocks.com/content/images/2019/01/121212_2_OpenSwissKnife-1.png)

Bountiful Open Source Summer

It's an online contribution platform for indian developers who are in college ,who wants to learn something new as well as get some prizes as a reward and most of it get recognition by one of the best teachers like arnav bhaiya,harshit bhaiya,prateek bhaiya.

I still remember my first query about BOSS was how to make a pull request using android studio,Yes i didn't even know how to make a pull request i didn't know about anything about open source or github.I was using gtihub for a past couple of months but all i know was git pull,git push and git clone.My first pul pull request was regarding code coverage and unit testing and before BOSS i haven't even heard of these terms i took me a while to understand these concepts but yes i actually learned something out of it and really enjoy that.

I also got to learn about some online github plugins like travis ci,codacy,codebeat etc which helped me a lot.I also got a lesson from arnav bhaiya that dont abuse these plugins and that's a lesson for life,i was trying to do something different even without having the knowledge how to do it just for the sake of points and i failed miserably but because of BOSS i got to know about different things which i'll try to learn,so without BOSS I wouldn't be able to know about these things.  
I must say these past 2 months have been most interesting months in development experience.

* * *

I have contributed to several issues so far and I am enjoying this program very much. I got the chance to contribute to the codebase,some UI chnages as well as the documentation.

It is a great option for those who don't about any thing about open source and before applying to wwdc or gsoc or any other online competition get a taste of open source.I would definately contribute to other online platforms as well coding bocks even after BOSS.

Thank You Coding Blocks and all the mentors for this amazing event.