---
title: "The best open source journey: BOSS"
date: "2017-08-14T22:45:00.000Z"
slug: "boss-experience-apoorvaa-gupta"
image: "https://blog.codingblocks.com/content/images/2019/06/coaching-coders-coding-7374-1.jpg"
description: "Hi everyone,  I am Apoorvaa Gupta, studying in Netaji Subhas Institute of Technology.  Everyone dreams of getting accepted in Google Summer of Code but does not know where and how to get started.  In this summer I wanted to get started with open source so that I could try for"
tags: []
original_url: "https://blog.codingblocks.com/2017/boss-experience-apoorvaa-gupta/"
---

Hi everyone,  
I am Apoorvaa Gupta, studying in Netaji Subhas Institute of Technology.

Everyone dreams of getting accepted in Google Summer of Code but does not know where and how to get started.  
In this summer I wanted to get started with open source so that I could try for GSOC next year. After wasting one week,  
I thought to give BOSS a try. I was not sure if contributing to BOSS would help me get started with open source. But after  
3 months i can definitely say that BOSS has been the best journey so far.

I came to know about such great developers, such great projects from BOSS. Now I can really say that I am an open-source  
contributor. I think BOSS is the best for someone who is just starting with open source.

I am really thankful to Coding Blocks for their open source event BOSS. This really helped me get started with open source  
and i can see myself trying for BOSS as well GSOC next year and hopefully getting accepted for both.

## ![download](https://blog.codingblocks.com/content/images/2019/01/download.jpg)

**Bountiful Open Source Summer**

It's an open source summer program just like Google Summer of Code, RGSoC, Season of KDE and many others.

And the best part is that it is open to all Indian students. Any student can start participating into it without any registration or selection process.

One can take up any open issue and start contributing to it. By solving an issue the participant gets bounty which is used to determined the winners of this program. Prizes are there to keep motivating the students.

![pexels-photo-136320](https://blog.codingblocks.com/content/images/2019/01/pexels-photo-136320.jpeg)

* * *

I have contributed to several issues so far and I am enjoying this program very much. I got the chance to contribute to the codebase as well as the documentation.

It is a great option for those who didn't get into GSoC this year. Those who wants to get the taste of open source this is a great place to start with.

* * *