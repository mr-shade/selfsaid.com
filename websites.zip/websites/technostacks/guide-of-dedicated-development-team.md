---
title: "Dedicated Development Team, How it Works?, Pros, Cons | Technostacks"
date: "2022-01-07T23:55:46+00:00"
slug: "guide-of-dedicated-development-team"
image: "https://technostacks.com/wp-content/uploads/2022/01/Dedicated-Development-Team.jpg"
description: "Find out here the detailed guide of a dedicated development team about how it works, when to use, when to ignore etc."
tags: []
original_url: "https://technostacks.com/blog/guide-of-dedicated-development-team/"
---

[![Technostacks logo](https://technostacks.com/wp-content/uploads/2025/02/techno-logo.svg)](https://technostacks.com/)

[![Technostacks logo](https://technostacks.com/wp-content/uploads/2025/03/mobile-logo.svg)](https://technostacks.com/)

*   [Services](https://technostacks.com/services/)
    
    *   *   ### Have a question?  
            Let us know.
            
            [Contact Us![](https://technostacks.com/wp-content/plugins/techno-2025-blocks/imgs/cta-arrow.svg)](https://technostacks.com/contact-us)
            
    *   *   *   [Advanced Technologies](https://technostacks.com/advanced-technologies/)
            *   [Cloud & DevOps](https://technostacks.com/cloud/)
            *   [Data & AI](https://technostacks.com/data-ai/)
                
            *   [Digital Products](https://technostacks.com/digital-products/)
            *   [Product Engineering](https://technostacks.com/product-engineering/)
            *   [Startup Consulting](https://technostacks.com/startup-consulting/)
        
        *   * * *
            
        *   [![chevron](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg)View all services](https://technostacks.com/services/)
        
    
*   [Our Work](https://technostacks.com/our-work/)
*   [About Us](https://technostacks.com/company-overview/)
*   [Career](https://technostacks.com/career/)
*   [Resources](https://technostacks.com/blog/)
*   [Get In Touch![Link](https://technostacks.com/wp-content/plugins/techno-2025-blocks/imgs/cta-arrow.svg)](https://technostacks.com/contact-us)
    

Close

[Get In Touch![Link](https://technostacks.com/wp-content/plugins/techno-2025-blocks/imgs/cta-arrow.svg)](https://technostacks.com/contact-us)

![Dedicated Development Team](https://technostacks.com/wp-content/uploads/2022/01/Dedicated-Development-Team.jpg)

![Technostacks Avatar](https://technostacks.com/wp-content/uploads/2023/04/Technostacks-PNG.png)

Written by

### 

Technostacks

Technostacks is a global IT solutions company specializing in AI, IoT, and SaaS, delivering innovative digital products for businesses.

### Share with your community!

[

![facebook](https://technostacks.com/wp-content/uploads/2025/02/facebook.svg)

](https://www.facebook.com/sharer/sharer.php?u=https://technostacks.com/blog/guide-of-dedicated-development-team/)[

![X](https://technostacks.com/wp-content/uploads/2025/02/twitter.svg)

](https://x.com/intent/tweet?url=https://technostacks.com/blog/guide-of-dedicated-development-team/&text=An Ultimate Guide of Dedicated Development Team)[

![linkedin](https://technostacks.com/wp-content/uploads/2025/02/linkedin.svg)

](https://www.linkedin.com/sharing/share-offsite/?url=https://technostacks.com/blog/guide-of-dedicated-development-team/)

[Designing & Development](https://technostacks.com/category/designing-development/)

# An Ultimate Guide of Dedicated Development Team

08 Jan 2022

A dedicated development team is formed due to the remote collaboration between the client and the firm, which acts as a partnership model for project completion.

It comes quite handy in various scenarios and is known to be very effective. The model is also declared as the perfect choice for both the well-established as well as the growing Startups.

Not to mention, the dedicated software development model is a cost-effective solution to any in-house development approach. However, if you are looking forward to hiring a dedicated development team, then introduce yourself to us, “Technostacks.”

We are a team of qualified developers with the required skills that you might be looking for in your project. With proven expertise and experience in software development, we help you achieve your goals and targets.

Moreover, we aim to reduce your overhead and deliver a unique product to the industry with hand-picked professionals at your disposal.

### How does a Development Team Work? Who is involved in the team?

Now that you already know about the dedicated team model. The next question is quite obvious: what does a development team do? or who is involved in the team? Well, like mentioned earlier, a dedicated software development approach lives up to its name.

It starts with the process where the hiring of dedicated developers is done with an organization that offers the goals, timeline, and scope of the project.

We at Technostacks always make sure to prioritize the skills of the dedicated team members and the number of developers that a client’s project requires.

Once this information is gathered, the vendor company starts to hire the developers. We have a group of experienced team members with a specific composition of skills that you may need according to your business needs. Therefore, to be precise, the group of members we own includes,

*   **The front end, back end, full-stack engineers –** these experts make sure to create client-side and server-side applications.
*   **Mobile developers –** just as the name suggests, they tend to create mobile applications according to the clients’ needs.
*   **UX / UI designers –** these experts establish simple and interactive user interfaces.
*   **Project and product managers –** they mediate between the clients and the developers. Their duties revolve around planning, managing, tracking progress besides mitigation of the risks involved.
*   **DevOps engineers –** these individuals coordinate the development, operation, and testing processes.
*   **Business analysts –** they assess the project requirement, user data, and analytics. Moreover, they also offer recommendations to the CEO and business owners.
*   **Quality assurance specialists-** these individuals make sure that there is a delivery of bug-free applications by establishing test plans and cases.

### When should you hire a dedicated development team?

*   **First level startup**  
    Any business that is in its first level is always looking forward to growing. They may have a fear of risk, but the passion for expanding does not fade either.Hence, in such times you may have the urge to hire us who have a team of dedicated developers. This will help you save both time and money, which is wasted in the hiring process. Also, it would help in developing the product faster.
*   **Shortage of development skills**  
    We keep ourselves aware of all the changing trends. We offer the required insights to the organizations besides experimenting with the new tools. Also, you can expect to receive exceptional products from the organization from us.Though the in-house team gets the access to enjoy different technologies, our dedicated software developers work on many projects, including different technology stacks, tools, and development styles.
*   **Projects with unclear requirements**  
    There would be times when your business would be handled with projects that have unclear and vague requirements.This is when you can count on us for the rescue. The time you would spend on discovering new things can lead to huge losses.
    
    Thus, when you hire our dedicated engineering team, you can expect to get timely resources to focus on the important things. Also, it will help to eliminate the fear of overspending or going through losses.
    
*   **Long term projects**  
    We have an experienced team of developers and they are suitable for long-term projects that are expandable. Not everyone has the power to unveil the potential of the projects.But our dedicated team of developers at Technostacks helps you go along the way. We make sure that we stay by your side until the end of the project and make it a success.

### Who is a better choice – a dedicated development team or an in-house team?

Usually, the most common debate among the business owners is which is better: dedicated development team vs. fixed budget team? According to us, trying to build a dedicated development team involves a lack of technology talent.

While the communication and management tools allow businesses to have a similar level of control over the process just as in-house developers, outsourcing can be a good option.

However, the biggest benefit of having a dedicated development team is that they can accelerate software development.

Probably it takes around three months to establish an engineering team on-site, and hiring cutting-edge technology remains another difficult factor to meet.

This is when the best approach to software development you can make is hiring a dedicated development team. Possessing the talents as well as quality resources, we make sure to build a team that can be more useful than an in-house one.

### What are the advantages of hiring a dedicated development team from us?

If you still have a trade of doubt left, then it is time to know why hiring an external team of web developers would be an advantage for you. So, let’s walk through those without wasting any time.

*   **Overcoming challenges**  
    Depending on the project goals and requirements, we prepare a tech roadmap and a hiring plan for the business industries.  
    The technical consultation in our team involves potential challenges and has a suitable tech stack to solve those challenges in no time.
*   **Conducting practical tests**  
    Another reason to build a dedicated development team with Technostacks is that they conduct practical tests.  
    These tests are conducted to vet the candidates depending on their skills set, code quality, performance, and others. Doing this helps to ensure that the clients would get the best-in-class developers.
*   **Great experience**  
    Our dedicated development team has decades of experience which promotes workflow through time zones, long-distance, and communication barriers.
*   **Availability**  
    We prioritize availability more than anything because we believe that communication is the key.  
    There are always video calls, daily stand-ups, and one-on-one check-ins conducted to stay connected to the clients.
*   **Affordability**  
    You don’t have to worry about spending tons on the training process and other valuable resources.Hiring a dedicated development team for your software development projects could be a tough decision.
    
    On the other hand, if you want to scale your internal team fast and cut off the extra cost, it will definitely be a worth it choice for your organization.
    
    Together with a dedicated development team from Technostacks, you can see your business growing in no time.
    

### Frequently Asked Questions (FAQ)

**Q1) What is a dedicated team in project management?**  
A dedicated team in project management can be defined as a model for long-term collaboration between a client and the development team.

In this format, a team of developers puts all their attention and focus on the clients’ projects.

They offer the guarantee that no one would switch to any other project besides the one they are committed to.

Besides that, they find the product-market fit, create UX and UI design, write the codes, offer quality assurance, and also maintain the product.

**Q2) What are the strategies for hiring a dedicated development team?**  
As a customer of today’s era, everyone is responsible enough to carry out research before they hire any company.

The customers make sure that they collect all the required information, including the credentials, pricing models, reviews of the previous clients, experience, and others.

However, there are some strategies that one must keep in mind.

*   **Get along with the newest trend of software development.**  
    Make sure that you begin by following the organization’s best practices. This would help improve the workflow and reduce the cost spent in experimenting and the risks.It also helps in offering efficiency. With the help of the trends, you would get to understand how far the experts have reached to receive the best performance.
*   **Follow the different agile methodologies.**  
    Agile methodologies are preferred for flexibility, continuous improvement, and efficiency as they are induced within the development teams.  
    Therefore, before you hire a team of dedicated developers, make sure to conduct a weekly meeting to understand if the project is heading in the right direction.
*   **Stick to the security protocols**  
    You already know that SDLC has security embedded at every stage. This could be one of the crucial factors to keep in mind when hiring a dedicated developer team.In this case, you can begin with discussing with the developers about their ideologies and practices that they are looking forward to implying to prevent security vulnerabilities.

**Q3) How to build a dedicated development team?**  
In order to create dedicated software, you would need to source the dedicated software developers possessing the right skills.

But where to start from could be a daunting task? So If you are looking forward to building a dedicated development team, then here are the steps which you must follow.

*   **Understand your needs**  
    The first thing you need to do is understand your needs. Before you contact the service provider, make sure to decide on a tech stack and prioritize the features.This would help the vendor to create a dedicated developer team according to the needs. On the other hand, when a vendor understands your needs, they tend to understand your company in a better way.
*   **Interviewing the candidates**  
    In the next step, conducting interviews is recommended during the hiring process. To be precise, the interviews are basically the technical and HR ones.While the interview is conducted, take the candidates to notice their company’s culture, communication and observe their other skills. Doing this will help you make a wise decision and shortlist the one who’s best for you.
*   **Publish your team**  
    After the selection of trusted team members is made, this would ensure your success. Just make sure to conduct multiple processes, including communication with the team members on a regular basis. Once this is done, now you can launch your team of skilled members.

**Q4) What is the main difference between a dedicated development model and a fixed budget model?**  
Sometimes the dedicated development model is confused with the fixed budget model. Though these two forms are quite similar, they still tend to be different.

The dedicated development model is better suited for long-term collaboration with higher degrees of complexities and urges for flexibility.  
While the fixed budget model is perfect for the shorter team project, which comes with specific requirements and has a clear idea of what needs to be achieved, here, the client has to pay an agreed amount of money for the number of hours worked.

There is no risk of overpayment here when compared to the dedicated development team, while the team receives complete freedom and space without making overpayments.

**Q5) Is hiring a dedicated development team better than the fixed budget team?**  
Hiring a dedicated development team over the fixed budget team completely depends on the requirements of the project.

If you have a long-term project, then choosing to go for the dedicated development team is recommended.

This is because the longer projects demand more complexity and flexibility, while if you have a short-term project, then going for the fixed one would be a good choice. This is because the requirements and goals are already known.

**Q6) What is the best time to hire a dedicated development team?**  
The dedicated development teams are perfect for long-term projects which demand flexibility. Projects that tend to be complex and need expansion in the future should get this type of team.

Another reason to hire them is when the idea of the product market does not fit and needs a discovery stage.

So, if you are at an early stage of startup or your project has vague requirements, then choosing the dedicated development team is recommended.

**Q7) When can you ignore hiring a dedicated development team?**  
Despite all the advantages that a dedicated development team comes with, sometimes it isn’t what you might need.

So here are some of the reasons when you should ignore hiring one.

*   **Short Term projects**  
    If you have a short-term project with clear and defined requirements or the scope is strictly outlined, then a dedicated development team is something you should ignore.In these times, choosing to go after a fixed-budget team would be a good decision.
*   **Strict timeline and budget**  
    Once you have received a strict budget and timeline for the project, then a dedicated development team is not something you should count on.Therefore, it is recommended to choose a fixed budget team to help receive the necessary results.

### Moving Forward

Technostacks offers a highly dedicated development team with years of expertise and knowledge that help the client organizations in a big way.

From conducting constant video calls to daily stand-ups, Technostacks make sure to continue a smooth communication with different stakeholders. They provide the best-in-class developers making sure that a unique product is delivered to the client. [Contact us](https://technostacks.com/contact-us/) to hire a dedicated development team for your project requirements.

In this article

## Resources

Expert insights to make you future-ready

[View All Resources![Link](https://technostacks.com/wp-content/plugins/techno-2025-blocks/imgs/cta-arrow.svg)](https://technostacks.com/blog)

*   ![Technostacks 2025 year in review](https://technostacks.com/wp-content/uploads/2025/12/2025-Wrapped.webp)
    
    Blog 4 min read
    
    ## [2025: A Year of Intent, Depth, and Direction](https://technostacks.com/blog/2025-year-review-technostacks/)
    
    A reflective look at milestones, mindset shifts, and progress in 2025.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): 2025: A Year of Intent, Depth, and Direction](https://technostacks.com/blog/2025-year-review-technostacks/)
    
*   ![Technology stack consulting for scalable and sustainable business growth](https://technostacks.com/wp-content/uploads/2025/12/Technology-stack-consulting-for-scalable-and-sustainable-business-growth.webp)
    
    Blog 8 min read
    
    ## [Choosing the Right Tech Stack for Sustainable Growth in 2026](https://technostacks.com/blog/choose-the-right-technology-stack-consulting/)
    
    Key factors to select a tech stack that supports long-term growth.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): Choosing the Right Tech Stack for Sustainable Growth in 2026](https://technostacks.com/blog/choose-the-right-technology-stack-consulting/)
    
*   ![Stay competitive in the AI-driven IT industry](https://technostacks.com/wp-content/uploads/2025/12/Stay-competitive-in-the-AI-driven-IT-industry.webp)
    
    Blog 9 min read
    
    ## [10 Proven Strategies to Stay Competitive in The IT Industry](https://technostacks.com/blog/strategies-for-staying-competitive-in-it/)
    
    How IT businesses can adapt, innovate, and lead in a changing market.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): 10 Proven Strategies to Stay Competitive in The IT Industry](https://technostacks.com/blog/strategies-for-staying-competitive-in-it/)
    
*   ![Top Mobile App Development Frameworks 2026](https://technostacks.com/wp-content/uploads/2025/12/Top-Mobile-App-Development-Frameworks-2026.webp)
    
    Blog 11 min read
    
    ## [Top 10 Programming Frameworks for App Development in 2026: The Complete Guide to Choosing the Best App Dev Framework](https://technostacks.com/blog/mobile-app-development-frameworks/)
    
    Why Mobile App Development Frameworks Matter in 2026 Today’s mobile market is intensely competitive with billions of active smartphone users worldwide, and businesses must deliver high-performance, intuitive apps that users genuinely value. Choosing the proper mobile app development framework is foundational to achieving this, since it directly influences time to market, development cost and complexity,…
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): Top 10 Programming Frameworks for App Development in 2026: The Complete Guide to Choosing the Best App Dev Framework](https://technostacks.com/blog/mobile-app-development-frameworks/)
    
*   ![TechBehemoths Global Excellence 2025](https://technostacks.com/wp-content/uploads/2025/12/Award-Banner-2.webp)
    
    Blog 3 min read
    
    ## [Technostacks wins global excellence industry recognition](https://technostacks.com/blog/technostacks-global-excellence-winner/)
    
    Celebrating innovation, delivery excellence, and global impact.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): Technostacks wins global excellence industry recognition](https://technostacks.com/blog/technostacks-global-excellence-winner/)
    
*   ![Enterprise Innovation & Future-Proofing](https://technostacks.com/wp-content/uploads/2025/12/Enterprise-Innovation-Future-Proofing.webp)
    
    Blog 5 min read
    
    ## [Advanced Technology Consulting for Enterprise Innovation](https://technostacks.com/blog/advanced-tech-consulting-enterprise-innovation/)
    
    How modern consulting drives scalable and future-ready enterprises.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): Advanced Technology Consulting for Enterprise Innovation](https://technostacks.com/blog/advanced-tech-consulting-enterprise-innovation/)
    
*   ![Banner showing emerging technologies powering digital transformation in 2025-26](https://technostacks.com/wp-content/uploads/2025/11/Banner-showing-emerging-technologies-powering-digital-transformation-in-2025-26.webp)
    
    Blog 8 min read
    
    ## [Top 5 Emerging Technologies 2026 for Business Digital Transformation](https://technostacks.com/blog/top-5-emerging-technologies/)
    
    Technologies reshaping industries and accelerating business growth.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): Top 5 Emerging Technologies 2026 for Business Digital Transformation](https://technostacks.com/blog/top-5-emerging-technologies/)
    
*   ![AI-assisted programming 2025](https://technostacks.com/wp-content/uploads/2025/11/programmer-home-talking-with-conscious-ai-superintelligence-using-vr-tech.webp)
    
    Blog 6 min read
    
    ## [AI-Assisted Programming in 2026: Transforming Software Development](https://technostacks.com/blog/ai-assisted-programming/)
    
    How AI tools are improving code quality, speed, and productivity.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): AI-Assisted Programming in 2026: Transforming Software Development](https://technostacks.com/blog/ai-assisted-programming/)
    
*   ![Off-the-Shelf-vs-Custom-Software-Best-ROI-for-Digital-Transformation](https://technostacks.com/wp-content/uploads/2025/09/Off-the-Shelf-vs-Custom-Software-Best-ROI-for-Digital-Transformation.png)
    
    Blog 6 min read
    
    ## [Off The-Shelf vs. Custom Software: Making the Right Choice](https://technostacks.com/blog/off-the-shelf-vs-custom-software/)
    
    Comparing flexibility, cost, and scalability for business software.
    
    [Read More![Link](https://technostacks.com/wp-content/uploads/2025/02/chevron.svg): Off The-Shelf vs. Custom Software: Making the Right Choice](https://technostacks.com/blog/off-the-shelf-vs-custom-software/)
    

![Previous Post](https://technostacks.com/wp-content/themes/techno-2025/imgs/slider-arrow.svg)

![Next Post](https://technostacks.com/wp-content/themes/techno-2025/imgs/slider-arrow.svg)

### Have a question?  
Let us know.

[Contact Us![Link](https://technostacks.com/wp-content/plugins/techno-2025-blocks/imgs/cta-arrow.svg)](https://technostacks.com/contact-us)

![AWS Certified](https://technostacks.com/wp-content/themes/techno-2025/imgs/aws.svg)

![Google Cloud Partner](https://technostacks.com/wp-content/themes/techno-2025/imgs/google-cloud.svg)

![Zoho Authorised Partner](https://technostacks.com/wp-content/themes/techno-2025/imgs/zoho.svg)

![ISO 27001:2013 Certificate](https://technostacks.com/wp-content/themes/techno-2025/imgs/iso.svg)

![Nasscom Affiliation](https://technostacks.com/wp-content/themes/techno-2025/imgs/nasscom.svg)

![Footer Background](https://technostacks.com/wp-content/themes/techno-2025/imgs/footer-bg.png)

### Redefining challenges, transforming experiences.

Cutting edge-solutions for seamless change.

### Quick Links

*   [Services](https://technostacks.com/services/)
*   [Resources](https://technostacks.com/blog/)

*   [Our Work](https://technostacks.com/our-work/)
*   [About Us](https://technostacks.com/company-overview/)
*   [Career](https://technostacks.com/career/)

### Career

[hr@technostacks.com](mailto:hr@technostacks.com)

[+91 99097 12616](tel:919909712616)

### USA

[18383 Preston Rd, #202  
Dallas, TX 75252](https://maps.app.goo.gl/hYXMEQQ79LgQGm5T8)

[+1 (510) 402-6022](tel:15104026022)

[info@technostacks.com](mailto:info@technostacks.com)

### India

[10th Floor, Sun Square, Navrangpura, Ahmedabad, Gujarat – 380006](https://www.google.com/maps/place/Technostacks+%7C+AI+Led+Software+Development+Company/@23.0333999,72.5540772,718m/data=!3m3!1e3!4b1!5s0x395e84f212bce68f:0x2877f7d71db46fe9!4m6!3m5!1s0x395e84f48f946df7:0x917f5b1f3ec95edc!8m2!3d23.0333999!4d72.5566521!16s%2Fg%2F1pv6yd_12?entry=ttu&g_ep=EgoyMDI1MDQyOS4wIKXMDSoASAFQAw%3D%3D)

[+91 97129 55934](tel:919712955934)

[info@technostacks.com](mailto:info@technostacks.com)

© 2026 Technostacks. All rights reserved.

[![Instagram](https://technostacks.com/wp-content/uploads/2025/03/instagram.svg)](https://www.instagram.com/technostacksinfotech/)

![LinkedIn](https://technostacks.com/wp-content/uploads/2025/03/linkedin.svg)

[![Twitter / X](https://technostacks.com/wp-content/uploads/2026/01/x.svg)](https://x.com/Technostacks)

{"prefetch":\[{"source":"document","where":{"and":\[{"href\_matches":"/\*"},{"not":{"href\_matches":\["/wp-\*.php","/wp-admin/\*","/wp-content/uploads/\*","/wp-content/\*","/wp-content/plugins/\*","/wp-content/themes/techno-2025/\*","/\*\\\\?(.+)"\]}},{"not":{"selector\_matches":"a\[rel~=\\"nofollow\\"\]"}},{"not":{"selector\_matches":".no-prefetch, .no-prefetch a"}}\]},"eagerness":"conservative"}\]} function dnd\_cf7\_generateUUIDv4() { const bytes = new Uint8Array(16); crypto.getRandomValues(bytes); bytes\[6\] = (bytes\[6\] & 0x0f) | 0x40; // version 4 bytes\[8\] = (bytes\[8\] & 0x3f) | 0x80; // variant 10 const hex = Array.from(bytes, b => b.toString(16).padStart(2, "0")).join(""); return hex.replace(/^(.{8})(.{4})(.{4})(.{4})(.{12})$/, "$1-$2-$3-$4-$5"); } document.addEventListener("DOMContentLoaded", function() { if ( ! document.cookie.includes("wpcf7\_guest\_user\_id")) { document.cookie = "wpcf7\_guest\_user\_id=" + dnd\_cf7\_generateUUIDv4() + "; path=/; max-age=" + (12 \* 3600) + "; samesite=Lax"; } }); jQuery(document).ready(function($){ var skills = '\[{"id":37,"tech":".Net","status":1,"isDeleted":0},{"id":192,"tech":"Accountant","status":1,"isDeleted":0},{"id":186,"tech":"AdMob","status":1,"isDeleted":0},{"id":139,"tech":"AES Encryption & Decryption","status":1,"isDeleted":0},{"id":159,"tech":"Agora.io","status":1,"isDeleted":0},{"id":169,"tech":"Amazon Rekognition","status":1,"isDeleted":0},{"id":5,"tech":"Android","status":1,"isDeleted":0},{"id":25,"tech":"AngularJs","status":1,"isDeleted":0},{"id":96,"tech":"Appium","status":1,"isDeleted":0},{"id":103,"tech":"ARCore","status":1,"isDeleted":0},{"id":91,"tech":"ARKit","status":1,"isDeleted":0},{"id":133,"tech":"Authorize.net","status":1,"isDeleted":0},{"id":93,"tech":"Automation Testing","status":1,"isDeleted":0},{"id":162,"tech":"AWS Amplify","status":1,"isDeleted":0},{"id":68,"tech":"AWS API GateWay","status":1,"isDeleted":0},{"id":167,"tech":"AWS CloudFormation","status":1,"isDeleted":0},{"id":66,"tech":"AWS CloudWatch","status":1,"isDeleted":0},{"id":170,"tech":"AWS CodeCommit","status":1,"isDeleted":0},{"id":70,"tech":"AWS CognitoPool","status":1,"isDeleted":0},{"id":60,"tech":"AWS EC2","status":1,"isDeleted":0},{"id":63,"tech":"AWS IAM","status":1,"isDeleted":0},{"id":102,"tech":"AWS IOT","status":1,"isDeleted":0},{"id":168,"tech":"AWS KMS","status":1,"isDeleted":0},{"id":67,"tech":"AWS Lambda","status":1,"isDeleted":0},{"id":116,"tech":"AWS lex","status":1,"isDeleted":0},{"id":61,"tech":"AWS Route53","status":1,"isDeleted":0},{"id":65,"tech":"AWS S3","status":1,"isDeleted":0},{"id":62,"tech":"AWS SES","status":1,"isDeleted":0},{"id":64,"tech":"AWS SNS","status":1,"isDeleted":0},{"id":164,"tech":"Azure Blob","status":1,"isDeleted":0},{"id":120,"tech":"Banner Design","status":1,"isDeleted":0},{"id":24,"tech":"BDE","status":1,"isDeleted":0},{"id":173,"tech":"Bitbucket","status":1,"isDeleted":0},{"id":31,"tech":"Blockchain Dev","status":1,"isDeleted":0},{"id":59,"tech":"Bootstrap CSS","status":1,"isDeleted":0},{"id":142,"tech":"BudgetSMS","status":1,"isDeleted":0},{"id":11,"tech":"Business Analyst","status":1,"isDeleted":0},{"id":15,"tech":"Business Development Executive","status":1,"isDeleted":0},{"id":40,"tech":"C++","status":1,"isDeleted":0},{"id":58,"tech":"CakePHP","status":1,"isDeleted":0},{"id":140,"tech":"Catchoom","status":1,"isDeleted":0},{"id":111,"tech":"CCIE","status":1,"isDeleted":0},{"id":109,"tech":"CCNA","status":1,"isDeleted":0},{"id":110,"tech":"CCNP","status":1,"isDeleted":0},{"id":172,"tech":"CircleCI","status":1,"isDeleted":0},{"id":22,"tech":"CodeIgniter","status":1,"isDeleted":0},{"id":32,"tech":"Content Writer","status":1,"isDeleted":0},{"id":89,"tech":"Core Data","status":1,"isDeleted":0},{"id":47,"tech":"CoreML","status":1,"isDeleted":0},{"id":119,"tech":"CRM","status":1,"isDeleted":0},{"id":9,"tech":"CSS","status":1,"isDeleted":0},{"id":118,"tech":"Data Analysis","status":1,"isDeleted":0},{"id":39,"tech":"Data Mining\\/ Research","status":1,"isDeleted":0},{"id":30,"tech":"DevOps","status":1,"isDeleted":0},{"id":14,"tech":"Digital Marketing","status":1,"isDeleted":0},{"id":83,"tech":"Django Framework","status":1,"isDeleted":0},{"id":84,"tech":"Django REST Framework","status":1,"isDeleted":0},{"id":53,"tech":"Docker","status":1,"isDeleted":0},{"id":69,"tech":"DynamoDB","status":1,"isDeleted":0},{"id":80,"tech":"ECMA5","status":1,"isDeleted":0},{"id":81,"tech":"ECMA6","status":1,"isDeleted":0},{"id":82,"tech":"Elasticsearch","status":1,"isDeleted":0},{"id":185,"tech":"Email Automation","status":1,"isDeleted":0},{"id":184,"tech":"Email marketing","status":1,"isDeleted":0},{"id":21,"tech":"Embedded","status":1,"isDeleted":0},{"id":143,"tech":"Face Recognition","status":1,"isDeleted":0},{"id":123,"tech":"Fast API","status":1,"isDeleted":0},{"id":79,"tech":"Firebase","status":1,"isDeleted":0},{"id":158,"tech":"Flask","status":1,"isDeleted":0},{"id":137,"tech":"Flurry","status":1,"isDeleted":0},{"id":29,"tech":"Flutter","status":1,"isDeleted":0},{"id":26,"tech":"Frontend Dev","status":1,"isDeleted":0},{"id":19,"tech":"Fullstack","status":1,"isDeleted":0},{"id":171,"tech":"Github","status":1,"isDeleted":0},{"id":190,"tech":"GitLab","status":1,"isDeleted":0},{"id":147,"tech":"Google Map APIs","status":1,"isDeleted":0},{"id":183,"tech":"Google sheet API","status":1,"isDeleted":0},{"id":28,"tech":"Graphics Designer","status":1,"isDeleted":0},{"id":163,"tech":"GraphQL","status":1,"isDeleted":0},{"id":115,"tech":"Gulp-SASS","status":1,"isDeleted":0},{"id":20,"tech":"HR","status":1,"isDeleted":0},{"id":4,"tech":"HTML","status":1,"isDeleted":0},{"id":134,"tech":"InApp Purchase","status":1,"isDeleted":0},{"id":6,"tech":"iOS","status":1,"isDeleted":0},{"id":33,"tech":"IT Recruiter","status":1,"isDeleted":0},{"id":41,"tech":"Java","status":1,"isDeleted":0},{"id":2,"tech":"JavaScript","status":1,"isDeleted":0},{"id":100,"tech":"Jenkins","status":1,"isDeleted":0},{"id":175,"tech":"JIRA","status":1,"isDeleted":0},{"id":99,"tech":"JMeter","status":1,"isDeleted":0},{"id":165,"tech":"Joomla E-Commerce","status":1,"isDeleted":0},{"id":3,"tech":"jQuery","status":1,"isDeleted":0},{"id":180,"tech":"Jupyter Notebook (Python)","status":1,"isDeleted":0},{"id":42,"tech":"Kivy","status":1,"isDeleted":0},{"id":43,"tech":"KivyMD","status":1,"isDeleted":0},{"id":131,"tech":"KNET","status":1,"isDeleted":0},{"id":36,"tech":"Kotlin","status":1,"isDeleted":0},{"id":1,"tech":"Laravel","status":1,"isDeleted":0},{"id":44,"tech":"LiDAR","status":1,"isDeleted":0},{"id":113,"tech":"Linux-OS","status":1,"isDeleted":0},{"id":114,"tech":"Mac-OS","status":1,"isDeleted":0},{"id":101,"tech":"Machine Learning","status":1,"isDeleted":0},{"id":48,"tech":"Magento","status":1,"isDeleted":0},{"id":146,"tech":"MailChimp","status":1,"isDeleted":0},{"id":127,"tech":"Mango Pay","status":1,"isDeleted":0},{"id":92,"tech":"Manual Testing","status":1,"isDeleted":0},{"id":144,"tech":"Mapbox","status":1,"isDeleted":0},{"id":121,"tech":"Market Research","status":1,"isDeleted":0},{"id":188,"tech":"Marketing Sales Funnel","status":1,"isDeleted":0},{"id":97,"tech":"Maven","status":1,"isDeleted":0},{"id":18,"tech":"MEAN\\/MERN Stack","status":1,"isDeleted":0},{"id":38,"tech":"MognoDB","status":1,"isDeleted":0},{"id":132,"tech":"Mollie","status":1,"isDeleted":0},{"id":55,"tech":"MySQL","status":1,"isDeleted":0},{"id":73,"tech":"NestJS","status":1,"isDeleted":0},{"id":107,"tech":"Network Design","status":1,"isDeleted":0},{"id":72,"tech":"NextJS","status":1,"isDeleted":0},{"id":13,"tech":"NodeJS","status":1,"isDeleted":0},{"id":85,"tech":"Numpy","status":1,"isDeleted":0},{"id":35,"tech":"Objective C","status":1,"isDeleted":0},{"id":46,"tech":"OpenCV","status":1,"isDeleted":0},{"id":86,"tech":"Pandas","status":1,"isDeleted":0},{"id":124,"tech":"PayPal","status":1,"isDeleted":0},{"id":130,"tech":"PayU","status":1,"isDeleted":0},{"id":128,"tech":"PayUMoney","status":1,"isDeleted":0},{"id":135,"tech":"PDF Generator","status":1,"isDeleted":0},{"id":23,"tech":"PHP","status":1,"isDeleted":0},{"id":160,"tech":"POLi Payments(NZ)","status":1,"isDeleted":0},{"id":56,"tech":"PostgreSQL","status":1,"isDeleted":0},{"id":12,"tech":"Project Manager","status":1,"isDeleted":0},{"id":90,"tech":"PubNub","status":1,"isDeleted":0},{"id":154,"tech":"PubNub","status":0,"isDeleted":0},{"id":138,"tech":"Push notification","status":1,"isDeleted":0},{"id":7,"tech":"Python","status":1,"isDeleted":0},{"id":17,"tech":"QA","status":1,"isDeleted":0},{"id":136,"tech":"QRCode Generator","status":1,"isDeleted":0},{"id":155,"tech":"QuickBlox","status":1,"isDeleted":0},{"id":156,"tech":"QuickBooks","status":1,"isDeleted":0},{"id":126,"tech":"Razorpay","status":1,"isDeleted":0},{"id":8,"tech":"React Native","status":1,"isDeleted":0},{"id":10,"tech":"ReactJs","status":1,"isDeleted":0},{"id":87,"tech":"RealityKit","status":1,"isDeleted":0},{"id":78,"tech":"Realm","status":1,"isDeleted":0},{"id":150,"tech":"Redis","status":1,"isDeleted":0},{"id":76,"tech":"Redux","status":1,"isDeleted":0},{"id":74,"tech":"Redux-saga","status":1,"isDeleted":0},{"id":75,"tech":"Redux-thunk","status":1,"isDeleted":0},{"id":166,"tech":"RoomDB (Android)","status":1,"isDeleted":0},{"id":189,"tech":"Scrum Master","status":1,"isDeleted":0},{"id":94,"tech":"Selenium IDE","status":1,"isDeleted":0},{"id":95,"tech":"Selenium WebDriver","status":1,"isDeleted":0},{"id":161,"tech":"Sendbird","status":1,"isDeleted":0},{"id":145,"tech":"Sendgrid","status":1,"isDeleted":0},{"id":187,"tech":"Sentry.io","status":1,"isDeleted":0},{"id":178,"tech":"Serverless","status":1,"isDeleted":0},{"id":179,"tech":"Shell Script","status":1,"isDeleted":0},{"id":49,"tech":"Shopify","status":1,"isDeleted":0},{"id":153,"tech":"Socket.io","status":1,"isDeleted":0},{"id":57,"tech":"SQLite","status":1,"isDeleted":0},{"id":149,"tech":"SSL Setup","status":1,"isDeleted":0},{"id":148,"tech":"SSO","status":1,"isDeleted":0},{"id":125,"tech":"Stripe","status":1,"isDeleted":0},{"id":174,"tech":"SVN","status":1,"isDeleted":0},{"id":34,"tech":"Swift","status":1,"isDeleted":0},{"id":71,"tech":"SwiftUI","status":1,"isDeleted":0},{"id":105,"tech":"Switches & Firewall Installation","status":1,"isDeleted":0},{"id":106,"tech":"Switching and Routing","status":1,"isDeleted":0},{"id":52,"tech":"Symfony","status":1,"isDeleted":0},{"id":129,"tech":"System Pay","status":1,"isDeleted":0},{"id":51,"tech":"Tailwind","status":1,"isDeleted":0},{"id":50,"tech":"Terraform","status":1,"isDeleted":0},{"id":98,"tech":"TestNG","status":1,"isDeleted":0},{"id":117,"tech":"Textract","status":1,"isDeleted":0},{"id":122,"tech":"threeJS","status":1,"isDeleted":0},{"id":108,"tech":"Troubleshooting","status":1,"isDeleted":0},{"id":141,"tech":"Twilio","status":1,"isDeleted":0},{"id":77,"tech":"Typescript","status":1,"isDeleted":0},{"id":27,"tech":"UI\\/UX Designer","status":1,"isDeleted":0},{"id":88,"tech":"VisonKit","status":1,"isDeleted":0},{"id":45,"tech":"VueJs","status":1,"isDeleted":0},{"id":104,"tech":"WAN Networking","status":1,"isDeleted":0},{"id":151,"tech":"Web Socket","status":1,"isDeleted":0},{"id":112,"tech":"Windows-OS","status":1,"isDeleted":0},{"id":16,"tech":"Wordpress","status":1,"isDeleted":0},{"id":177,"tech":"Yii (PHP)","status":1,"isDeleted":0},{"id":157,"tech":"Zero Accounting","status":1,"isDeleted":0},{"id":152,"tech":"ZMQ","status":1,"isDeleted":0},{"id":191,"tech":"Zoom Meeting API","status":1,"isDeleted":0},{"id":181,"tech":"Zustand","status":1,"isDeleted":0}\]'; skills = JSON.parse(skills); var skillsOptions = skills.map(function(item) { return { id: item.id, text: item.tech }; }); var skillselect = $('select\[name=skill-set\]'); $(skillselect).select2({ data: skillsOptions, multiple: true, placeholder: 'Select Skills' }); $(skillselect).on('change', function (e) { var skillsvalues = $(skillselect).select2('data'); var skillsetdeck = skillsvalues.map(function(skill){ return skill.id; }); $('#skill-set-deck').val(skillsetdeck.toString()); var skillsetemail = skillsvalues.map(function(skill){ return skill.text; }); $('#skill-set-email').val(skillsetemail.toString()); }); var min = $('#total-experience-element').attr('min'); var max = $('#total-experience-element').attr('max'); for(var i = min; i <= max; i++){ $('.ticks').append('<span class="tick">'+i+'</span>'); } $('#total-experience-element').on('change', function () { $('#total-experience').val($(this).val()); }); }); if (navigator.platform.toUpperCase().includes('MAC')) { document.body.classList.add('is-mac'); } var technostacks\_data = {"ajax\_url":"https://technostacks.com/wp-admin/admin-ajax.php","site\_url":"https://technostacks.com","plugin\_url":"https://technostacks.com/wp-content/plugins/techno-2025-blocks"}; //# sourceURL=technostacks-js-extra ( function() { var skipLinkTarget = document.querySelector( 'main' ), sibling, skipLinkTargetID, skipLink; // Early exit if a skip-link target can't be located. if ( ! skipLinkTarget ) { return; } /\* \* Get the site wrapper. \* The skip-link will be injected in the beginning of it. \*/ sibling = document.querySelector( '.wp-site-blocks' ); // Early exit if the root element was not found. if ( ! sibling ) { return; } // Get the skip-link target's ID, and generate one if it doesn't exist. skipLinkTargetID = skipLinkTarget.id; if ( ! skipLinkTargetID ) { skipLinkTargetID = 'wp--skip-link--target'; skipLinkTarget.id = skipLinkTargetID; } // Create the skip link. skipLink = document.createElement( 'a' ); skipLink.classList.add( 'skip-link', 'screen-reader-text' ); skipLink.id = 'wp-skip-link'; skipLink.href = '#' + skipLinkTargetID; skipLink.innerText = 'Skip to content'; // Inject the skip link. sibling.parentElement.insertBefore( skipLink, sibling ); }() ); //# sourceURL=wp-block-template-skip-link-js-after wp.i18n.setLocaleData( { 'text direction\\u0004ltr': \[ 'ltr' \] } ); //# sourceURL=wp-i18n-js-after var wpcf7 = { "api": { "root": "https:\\/\\/technostacks.com\\/wp-json\\/", "namespace": "contact-form-7\\/v1" }, "cached": 1 }; //# sourceURL=contact-form-7-js-before var dnd\_cf7\_uploader = {"ajax\_url":"https://technostacks.com/wp-admin/admin-ajax.php","ajax\_nonce":"1de1dff79d","drag\_n\_drop\_upload":{"tag":"h3","text":"Drag & Drop Files Here","or\_separator":"or","browse":"Browse Files","server\_max\_error":"The uploaded file exceeds the maximum upload size of your server.","large\_file":"Uploaded file is too large","inavalid\_type":"Uploaded file is not allowed for file type","max\_file\_limit":"Note : Some of the files are not uploaded ( Only %count% files allowed )","required":"This field is required.","delete":{"text":"deleting","title":"Remove"}},"dnd\_text\_counter":"of","disable\_btn":""}; //# sourceURL=codedropz-uploader-js-extra var wpcf7r = {"ajax\_url":"https://technostacks.com/wp-admin/admin-ajax.php"}; //# sourceURL=wpcf7-redirect-script-js-extra var wpcf7\_recaptcha = { "sitekey": "6LetLXsqAAAAABCW2w554qT7XBtsqB-SyuEIf-Kg", "actions": { "homepage": "homepage", "contactform": "contactform" } }; //# sourceURL=wpcf7-recaptcha-js-before var ubermenu\_data = {"remove\_conflicts":"on","reposition\_on\_load":"off","intent\_delay":"300","intent\_interval":"100","intent\_threshold":"7","scrollto\_offset":"50","scrollto\_duration":"1000","responsive\_breakpoint":"959","accessible":"on","mobile\_menu\_collapse\_on\_navigate":"on","retractor\_display\_strategy":"responsive","touch\_off\_close":"on","submenu\_indicator\_close\_mobile":"on","collapse\_after\_scroll":"on","v":"3.8.5","configurations":\["main"\],"ajax\_url":"https://technostacks.com/wp-admin/admin-ajax.php","plugin\_url":"https://technostacks.com/wp-content/plugins/ubermenu/","disable\_mobile":"off","prefix\_boost":"","use\_core\_svgs":"off","aria\_role\_navigation":"off","aria\_nav\_label":"off","aria\_expanded":"off","aria\_haspopup":"off","aria\_hidden":"off","aria\_controls":"","aria\_responsive\_toggle":"off","icon\_tag":"i","esc\_close\_mobile":"on","keyboard\_submenu\_trigger":"enter","theme\_locations":\[\]}; //# sourceURL=ubermenu-js-extra !function(e,n){if("undefined"!=typeof EnlighterJS){var o={"selectors":{"block":"pre.EnlighterJSRAW","inline":"code.EnlighterJSRAW"},"options":{"indent":4,"ampersandCleanup":true,"linehover":true,"rawcodeDbclick":false,"textOverflow":"break","linenumbers":true,"theme":"dracula","language":"generic","retainCssClasses":false,"collapse":false,"toolbarOuter":"","toolbarTop":"{BTN\_RAW}{BTN\_COPY}{BTN\_WINDOW}{BTN\_WEBSITE}","toolbarBottom":""}};(e.EnlighterJSINIT=function(){EnlighterJS.init(o.selectors.block,o.selectors.inline,o.options)})()}else{(n&&(n.error||n.log)||function(){})("Error: EnlighterJS resources not loaded yet!")}}(window,console); //# sourceURL=enlighterjs-js-after var technostacks\_theme = {"ajax\_url":"https://technostacks.com/wp-admin/admin-ajax.php","site\_url":"https://technostacks.com","theme\_url":"https://technostacks.com/wp-content/themes/techno-2025"}; //# sourceURL=techno-main-js-extra {"baseUrl":"https://s.w.org/images/core/emoji/17.0.2/72x72/","ext":".png","svgUrl":"https://s.w.org/images/core/emoji/17.0.2/svg/","svgExt":".svg","source":{"concatemoji":"https://technostacks.com/wp-includes/js/wp-emoji-release.min.js?ver=6.9"}} /\*! This file is auto-generated \*/ const a=JSON.parse(document.getElementById("wp-emoji-settings").textContent),o=(window.\_wpemojiSettings=a,"wpEmojiSettingsSupports"),s=\["flag","emoji"\];function i(e){try{var t={supportTests:e,timestamp:(new Date).valueOf()};sessionStorage.setItem(o,JSON.stringify(t))}catch(e){}}function c(e,t,n){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);t=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(n,0,0);const a=new Uint32Array(e.getImageData(0,0,e.canvas.width,e.canvas.height).data);return t.every((e,t)=>e===a\[t\])}function p(e,t){e.clearRect(0,0,e.canvas.width,e.canvas.height),e.fillText(t,0,0);var n=e.getImageData(16,16,1,1);for(let e=0;e<n.data.length;e++)if(0!==n.data\[e\])return!1;return!0}function u(e,t,n,a){switch(t){case"flag":return n(e,"\\ud83c\\udff3\\ufe0f\\u200d\\u26a7\\ufe0f","\\ud83c\\udff3\\ufe0f\\u200b\\u26a7\\ufe0f")?!1:!n(e,"\\ud83c\\udde8\\ud83c\\uddf6","\\ud83c\\udde8\\u200b\\ud83c\\uddf6")&&!n(e,"\\ud83c\\udff4\\udb40\\udc67\\udb40\\udc62\\udb40\\udc65\\udb40\\udc6e\\udb40\\udc67\\udb40\\udc7f","\\ud83c\\udff4\\u200b\\udb40\\udc67\\u200b\\udb40\\udc62\\u200b\\udb40\\udc65\\u200b\\udb40\\udc6e\\u200b\\udb40\\udc67\\u200b\\udb40\\udc7f");case"emoji":return!a(e,"\\ud83e\\u1fac8")}return!1}function f(e,t,n,a){let r;const o=(r="undefined"!=typeof WorkerGlobalScope&&self instanceof WorkerGlobalScope?new OffscreenCanvas(300,150):document.createElement("canvas")).getContext("2d",{willReadFrequently:!0}),s=(o.textBaseline="top",o.font="600 32px Arial",{});return e.forEach(e=>{s\[e\]=t(o,e,n,a)}),s}function r(e){var t=document.createElement("script");t.src=e,t.defer=!0,document.head.appendChild(t)}a.supports={everything:!0,everythingExceptFlag:!0},new Promise(t=>{let n=function(){try{var e=JSON.parse(sessionStorage.getItem(o));if("object"==typeof e&&"number"==typeof e.timestamp&&(new Date).valueOf()<e.timestamp+604800&&"object"==typeof e.supportTests)return e.supportTests}catch(e){}return null}();if(!n){if("undefined"!=typeof Worker&&"undefined"!=typeof OffscreenCanvas&&"undefined"!=typeof URL&&URL.createObjectURL&&"undefined"!=typeof Blob)try{var e="postMessage("+f.toString()+"("+\[JSON.stringify(s),u.toString(),c.toString(),p.toString()\].join(",")+"));",a=new Blob(\[e\],{type:"text/javascript"});const r=new Worker(URL.createObjectURL(a),{name:"wpTestEmojiSupports"});return void(r.onmessage=e=>{i(n=e.data),r.terminate(),t(n)})}catch(e){}i(n=f(s,u,c,p))}t(n)}).then(e=>{for(const n in e)a.supports\[n\]=e\[n\],a.supports.everything=a.supports.everything&&a.supports\[n\],"flag"!==n&&(a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&a.supports\[n\]);var t;a.supports.everythingExceptFlag=a.supports.everythingExceptFlag&&!a.supports.flag,a.supports.everything||((t=a.source||{}).concatemoji?r(t.concatemoji):t.wpemoji&&t.twemoji&&(r(t.twemoji),r(t.wpemoji)))}); //# sourceURL=https://technostacks.com/wp-includes/js/wp-emoji-loader.min.js (function(){function c(){var b=a.contentDocument||a.contentWindow.document;if(b){var d=b.createElement('script');d.innerHTML="window.\_\_CF$cv$params={r:'9b88f730992e7a04',t:'MTc2NzUxMTE0Ni4wMDAwMDA='};var a=document.createElement('script');a.nonce='';a.src='/cdn-cgi/challenge-platform/scripts/jsd/main.js';document.getElementsByTagName('head')\[0\].appendChild(a);";b.getElementsByTagName('head')\[0\].appendChild(d)}}if(document.body){var a=document.createElement('iframe');a.height=1;a.width=1;a.style.position='absolute';a.style.top=0;a.style.left=0;a.style.border='none';a.style.visibility='hidden';document.body.appendChild(a);if('loading'!==document.readyState)c();else if(window.addEventListener)document.addEventListener('DOMContentLoaded',c);else{var e=document.onreadystatechange||function(){};document.onreadystatechange=function(b){e(b);'loading'!==document.readyState&&(document.onreadystatechange=e,c())}}}})();