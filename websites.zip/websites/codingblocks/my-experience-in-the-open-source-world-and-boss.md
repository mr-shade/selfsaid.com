---
title: "My experience in the open source world and boss"
date: "2018-12-11T21:29:15.000Z"
slug: "my-experience-in-the-open-source-world-and-boss"
image: "https://blog.codingblocks.com/content/images/2019/01/4k-wallpaper-android-wallpaper-cobweb-1527634-1.jpg"
description: "Hello, Everyone!  I am Dhroov gupta. BTech Undergraduate student at The NorthCap University,Gurgaon.  I am participating in the BOSS 2018.  It's my first experience in the open source development and i am enjoying contributing int it.  When you write a piece of code and the whole community see and"
tags: []
original_url: "https://blog.codingblocks.com/2018/my-experience-in-the-open-source-world-and-boss/"
---

Hello, Everyone!  
I am Dhroov gupta. BTech Undergraduate student at The NorthCap University,Gurgaon.  
I am participating in the BOSS 2018.  
It's my first experience in the open source development and i am enjoying contributing int it.  
When you write a piece of code and the whole community see and appreciate your work,it feels amazing and  
it motivates you to contribute more.  
BOSS 2018 has almost completed one month and i am contributing since then, i can say that these days taught me  
a lot more than my entire time since i learned web development.

* * *

One thing that I liked about BOSS is that it is open to all.

A **Real Open Source Event**

I am contributing mostly in oneauth and boss website and i am learning alot as the  
issues are challenging but when you start  
working on that issue you get to know a lot of new stuff and if your code get merge then you'll get  
motivation to contribute more and more.

I can assure this if i win this or not, i will gain alot of experience,knowledge and motivation to do more  
and be a better developer.

And also i want to thank you coding blocks for giving this platform to all the students to introduce the open source  
and that knowledge and experience can give them motivation and in the future can do bigger things.

Cheers to all the mentors and contributors.