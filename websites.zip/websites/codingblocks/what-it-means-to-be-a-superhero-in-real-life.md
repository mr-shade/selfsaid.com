---
title: "What it means to be a Superhero in REAL Life"
date: "2019-06-22T20:33:25.000Z"
slug: "what-it-means-to-be-a-superhero-in-real-life"
image: "https://blog.codingblocks.com/content/images/2019/05/img-academic-advisors-superhero.jpg"
description: "~ Nitin Mittal ( Campus Superhero MAIT ) It has been more than two years since I have been a part of Coding blocks family. I went from being a normal student to Coding Blocks Superhero and then to a Teaching assistant. I’m sure you’re curious about what it means to"
tags: []
original_url: "https://blog.codingblocks.com/2019/what-it-means-to-be-a-superhero-in-real-life/"
---

~ Nitin Mittal ( Campus Superhero MAIT )

It has been more than two years since I have been a part of Coding blocks family. I went from being a normal student to Coding Blocks Superhero and then to a Teaching assistant. I’m sure you’re curious about what it means to be a part of Coding blocks family. Well, sit back and let me tell you all about it.

It was summer afternoon in May 2017 after I gave my all entrance exams, a message popped up on my phone from Manmohan Gupta sir (founder of Coding Blocks and VMC) in VMC whatsapp class group about Coding Blocks. I knew nothing about coding so I jumped to their website and learn about different courses they have. By evening, I was enrolled in an online course for Basic C++ (Launchpad). I was excited to enter into the world of coding. The course was mentored by Prateek Bhaiya and during the course, I got to know about Prateek Bhaiya and his exciting stories about how his student was hired in a company when the HR saw in his resume that he was mentored by Mr. [Prateek Narang](http://www.prateeknarang.com/).

It was then when I decided to join offline course for Algo C++ in December. I was in my first year and it gave me a platform to learn so much, develop my coding skills and meet new people. The environment at Coding Blocks is the healthiest I have ever seen. I completed my course in March 2018.

![](https://blog.codingblocks.com/content/images/2019/05/IMG-4556-1.jpg)

It was May 2018, when I was going through their website to register myself in another advance course for summer. I saw a link about Coding Blocks Campus Ambassadors on that webpage. I was interested to get involved within the campus, meet new people, and improve my competence on both professional and personal front. I applied for it online after answering some of the questions about why will I be fit for this position and how will I promote Coding Blocks in my campus. My application was selected and got a call from Coding Blocks for a telephonic interview which was conducted by Jatin Bhaiya. He asked me about my past experiences, my leadership skills and 15 minutes later I was a Coding Blocks superhero.

Two days later, I received an offer letter saying, “Welcome Superhero”. The feeling is unexplainable. It also included my promo code CBCAO051 and details about what I have to do and what will I get from this program. The program offers the opportunity to gain experience in managerial and technical fronts. From organizing events to speaking confidently in public, it lays the groundwork for the betterment of personality. Also I was added to a WhatsApp group which landed me an opportunity to interact with the different CAs from all over India.

It was very difficult in the beginning since I was not able to meet my goals on time. I was having a hard time trying to prioritize my work but there was no other way, as it was not only an adaptive process but also a great learning experience. It was becoming difficult to even get permissions for any event from Coding Blocks but the mentorship provided by [Jatin](https://www.linkedin.com/in/jatin-virmani-6a8650b8/) Bhaiya was profound. He introduced me to my senior Sanket Bhaiya, Campus ambassador and Co-Mentor at Coding Blocks. He helped me in organizing events and managing everything. Yeah, I can say that I got my best senior in my college. We planned our first Workshop on Blockchain which is in Demand now a days. The workshop was conducted by Mr. Anuj Garg on 4th October 2018. We organized everything, from getting support from our college faculty to managing everything from technical to non-technical work; the workshop turned out to be a great success. Everyone loved it and we also got suggestions from students for starting a course on Blockchain in coding Blocks. This program pushed me out of my comfort zone, made me interact with my college mates as well as with students from outside. In the meantime, the community of Coding Blocks Superheroes expanded. It is an incredible experience to get in touch with superheroes of other colleges, 300+ Superheroes sharing their ideas, doubts and in addition to learning, not missing out on fun. I became appreciative of the fact that people are the foundation of a community.

![](https://blog.codingblocks.com/content/images/2019/05/DSC_0010.JPG)

Someone has rightly said that all work and no play makes Jack a dull boy. Keeping this in mind, the mentors organized an outing to Adventure Island on December 26th, where we not only met other superheroes from different colleges but also got to interact with them. We had a great time there; we were dancing, playing, eating. They usually have celebrations for almost all the festivals. You can also attend any other event of CB all over the country. All this allowed me to not only build myself but most importantly made me fall in love with CB.

There is professionalism, but not to a level of insensitivity. Your mentors guide you in every aspect, from career counselling to helping out at stuck up problems to getting incentives from CB. I made some good friends, but I met some great mentors here. Once a part of CB Family, the portal for n number of internships open up for you. You also get the opportunity to become Teaching Assistant (TA) and most importantly getting acknowledged when you work well motivates one to work even better! I had my first Teaching Experience in Launchpad Course in December 2018. I was mentored by Prateek bhaiya and I learned how it feels to be on the other side of the class. It helped me learn new concepts, enhanced my thinking skills by debugging codes of other students and on top of that made me a more confident person. Ta-ing can be fun and productive if you choose to make it so. And can be frustrating if you choose otherwise.

In January 2019, Coding Blocks decided to open its first ever Coding Blocks student chapter – Campus Blocks in MAIT. I, along with [sanket](https://www.linkedin.com/in/singhsanket143/) bhaiya and [Sarthak](https://www.linkedin.com/in/sarthak-jain24apr98/) bhaiya, ( Intern at coding Blocks and also my senior) organized everything, from taking permissions for opening of the Chapter to its first ever Campus blocks Event On 25th January 2019. The event was on “Open Source software development” which was conducted by Mr. Arnav Gupta (Founding Member at coding Blocks) and Mr. Harshit Dwivedi (Former GSoCer, Speaker at DEVOXX Belgium and instructor at Coding Blocks) Along with Mr. Priyanshu aggarwal (Founding member at coding Blocks) and Mr. Varun Hasija (Head of Engineering at Coding Block). The workshop was a great success and was attended by 100+ students. It was a great start for Student chapter - Campus Blocks. Not just this, but we organized “Days of hack’19” a two-day Hackathon on 7-8th February and an event on “Linux installation Party” on 14th February (yeah on Valentine’s day) in which we helped students to get their laptops dual boot with Linux. It was really fun as we also provided students with snacks after complete installation of Ubuntu on their Laptops.

![](https://blog.codingblocks.com/content/images/2019/05/SuperHero_popart_genericBanner.jpg)

In February, my brother, who is in first year in UIET, Panjab University asked me to organize a workshop or a coding contest in their college. So I talked to Jatin bhaiya and decided the dates and timing for the contest and finalized it on 28th February 2019. And soon, I also organized a workshop on “Machine Learning” on 3rd April 2019 in UIET with help from my brother and other Campus Ambassadors there. Workshop was mentored by Suransh bhaiya and it was a great success with 150+ students attending the workshop.

Most importantly getting acknowledged when you work well, motivates you to work even better! On 3rd May 2019, I was preparing for my exam when notification appeared on my phone screen that coding Blocks tagged you in a photo. I thought it would be a meme or something else, but when I saw “**SUPERHERO OF THE MONTH APRIL**”. I was like “Oh my God, Nothing is better than this.” Soon the post was there all over the social media. And trust me it was awesome getting praised by everyone.

![](https://blog.codingblocks.com/content/images/2019/05/image-1.png)

I truly am grateful for being a part of the amazing CB family. I can, with utmost pride, say that I have grown my network of support and am prepared for the forthcoming challenges. And I am not going anywhere anytime soon because one thing that makes coding blocks great is its friendly environment and a great learning workspace. They treat us like a family.

Thank you Jatin Bhaiya, Priyanshu bhaiya, Prateek bhaiya and of course thank you Coding Blocks for providing me with innumerable opportunities! ❤

Do you enjoy organizing events, debugging some crazy codes along with bringing people together? Do you need excellent guidance under the mentors of Coding Blocks family? Want to be a part of it and attend many different events and most importantly have fun while working? Then this is the place for you. Become a Coding Blocks Superhero today.

[https://codingblocks.com/campus-ambassador-program.html](https://codingblocks.com/campus-ambassador-program.html%20%0b%0b)

You can find me at: [https://www.linkedin.com/in/nitin-mittal-119024129](https://www.linkedin.com/in/nitin-mittal-119024129)