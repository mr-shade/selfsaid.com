---
title: "Environment Engineering Student Cracks Walmart SDE  Role - Know how ISM Dhanbad student made it possible!"
date: "2019-09-17T11:45:35.000Z"
slug: "interview-of-kasa-praneeth-yadav"
image: "https://blog.codingblocks.com/content/images/2019/09/WALMART-cover.png"
description: "Kasa Praneeth Yadav, an Environmental Engineering student at ISM Dhanbad cracked placement at Walmart Labs as Software Development Engineer profile. It is his Interview Experience for SDE at Walmart Labs. He has set another precedent that branch is not important in achieving your dream.   Learn Data Structures Algorithms for Interviews,"
tags: []
original_url: "https://blog.codingblocks.com/2019/interview-of-kasa-praneeth-yadav/"
---

Kasa Praneeth Yadav, an Environmental Engineering student at ISM Dhanbad cracked placement at Walmart Labs as Software Development Engineer profile. It is his Interview Experience for SDE at Walmart Labs. He has set another precedent that branch is not important in achieving your dream.  

[

Learn Data Structures Algorithms for Interviews, and non coding topics!

Learn Data Structures Algorithms for Interviews, and non coding topics!

Coding Blocks Online

![](https://minio.codingblocks.com/amoeba/215fa6ed-14f3-4d1e-87d5-d9d71cf0d0dd.svg)

](https://online.codingblocks.com/courses/coding-interview-preparation-course-online-c-plus-plus)

Get Placed with CB Interview Preparation Course

## Questions and His Answers :-

**What were the eligibility criteria (including GPA and no. of internship) that needs to be fulfilled by the applicant?**

GPA – Over 7 and having an internship  is an added advantage or else the student should be equipped with a  legit reason for not having an internship.

**Does having a higher GPA gives the applicant an advantage?**

I personally don’t have a high GPA, So  I testify the fact that GPA isn’t the sole reason to secure a  Placement. But having a decent GPA of 8 is helpful when certain  companies filter through GPA. But if one doesn’t have a good enough GPA,  he/she has to be genuinely strong to secure a placement on Day 0,  trumping his/her peers with higher GPA.

**What are the necessary preparations that an applicant must do apart from making a concise CV?**

I think, the initial phase of clearing  the coding rounds would require a decent amount of Programming Skills.  The latter phase would require the student to be diligent enough to  express the requisite answers. The companies are not just looking for a  good resume, they are looking for students who are expressive and good  problem solvers.

**How did the concepts which you studied at IIT ISM help?**

Nil-I’m an environmental engineer all set to work as a software developer.

**Do you think networks with professional organisations help us in getting a good placement?**

Yes, it would help someone to get a  referral from his/her connections, and definitely some helpful guidance  in cracking the interviews.

**How was the selection procedure of the placement?**

First there was a coding round,  followed by the shortlist, later there were two technical rounds,  concluding with two HR interviews.

**Can you share your experience of HR and technical interview.**

I went to the interview at 3 PM. My  name was in the end of the list. I waited till 8 PM and my name was  still not called. I had my earpiece on and started doing Michael  Jackson’s moonwalk to calm my nerves. I asked the Student Coordinator to  inform me as soon as my name was called. After a considerable amount of  waiting, it was 10 PM. I asked the Student Coordinator as I can see  every student giving their 2nd or 3rd interviews. He replied that I  wasn’t eligible for the interview as I am from Environmental  Engineering. But I’ve a Minor is Computer Science. So, I questioned why  did they let me take the Coding round and select me in the first place  if I’m not eligible. I felt let down and left the place. But my friends  made me realise the time I invested and motivated me constantly to go  and confront them. This time, I succeeded after certain internal  conversations with the CDC, SCPT and the HR. The HR came and I told him  it would be fair if they reject me after the interview and not like  this, and they accepted. Clock ticked 12 – 9 Hours of Waiting, just  prompted me to answer all the questions perfectly and prove them wrong.

I went inside and the interviewer  schooled me with a considerably tough question – DP on Trees, maybe to  end the interview asap, as I was the last one left. I successfully  completed the question and the interview. He wanted to test me on ML and  AI, as I had an internship on a Deep Learning Project. In the end of  both the interviews, they were impressed. But they were concerned about  my GPA and told that I can’t enter Walmart with this GPA. I replied that  I received A+’s and A’s in my Minor Course on Computer Science. They  directed me towards 2 formal HR interviews. In the end, I noticed them  mentioning that I’d add value to their company in their feedback form.  All these 4 rounds of interviews ended at 2:30 AM. I was quite positive  that I would be selected.I received the result in the morning.

**What are the main qualities that selectors look for in a candidate? And do communication skills matter?**

Being expressive is definitely the key  to clearing an interview. Calm thought process is preferred over being  anxious and the pressure should never get to you. Communication skills  don’t matter as long as the message is conveyed explicitly.

**What advice would you like to give to your juniors?**

I am saying this because you asked me to. Life is a battlefield. God put all of us in a war zone.Be Alert! Protect Yourself! Keep a Goal in your life, and do anything to achieve it.  
If you want to sing, sing with focus; If you want to study, study with focus.  
The people who have no goal in life, die as fast as you can because  there is no use with you.Remember one thing, that there is no one with  greater potential than you.  
Do whatever you like and do not listen to anyone, especially to a human being.  
If your target is 10 miles, aim for the 11th mile. If you hit the right  cord, it should brainwash the person at the receiving end. Chal!

![](https://blog.codingblocks.com/content/images/2019/09/image.png)

**Kasa Praneeth Yadav**‌‌ -‌‌ **Environmental Engineering**‌‌

~ **Kasa Praneeth Yadav**  
**Final year Student**  
**Environmental Engineering -** IIT(ISM)  
**Placed at Walmart Labs**