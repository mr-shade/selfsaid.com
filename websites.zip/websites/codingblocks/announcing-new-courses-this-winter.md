---
title: "Announcing New Courses This Winter"
date: "2017-11-03T13:01:00.000Z"
slug: "announcing-new-courses-this-winter"
image: "https://blog.codingblocks.com/content/images/2018/12/java_apps.png"
description: "At Coding Blocks, over more than 3 years now, we have been hard at work, striving to create the best possible journey into the world of programming for thousands of aspiring software developers. In these years, we have had the fortune of having close to 10,000 budding programmers come"
tags: []
original_url: "https://blog.codingblocks.com/2017/announcing-new-courses-this-winter/"
---

At Coding Blocks, over more than 3 years now, we have been hard at work, striving to create the best possible journey into the world of programming for thousands of aspiring software developers. In these years, we have had the fortune of having close to 10,000 budding programmers come and learn a variety of skills including **Data Structures and Algorithms**, **Mobile App Development**, **Web Backend and Frontend Development**, and more recently, **Game Development** and **Machine Learning**.

[

Best online computer programming and coding courses in India.

Coding Blocks is the best online programming and software training Institute offer online certification courses in Jave, C++, Android, NodeJs, Data structure, Machine learning, Interview preparation and more.

Coding Blocks Online

![](https://minio.codingblocks.com/amoeba/OnlineLogo2020_LIGHT_logofull.png)

](https://online.codingblocks.com/courses)

Learn Online Coding

As more days go by, and we interact with more and more of our students (most of whom are undergraduate engineering students), we get to know better the requirements, better approaches, and how better to package this journey.

Building on top of most of our learnings of the past year, and taking feedback from numerous former Coding Blocks students, and also experts from the software industry, we tweaked around some of our programmes, and are launching some entirely new programmes.

I am really pleased to announce the following new programmes being launched from December, 2017 at _**Coding Blocks**_

![](https://blog.codingblocks.com/content/images/2018/12/image.png)