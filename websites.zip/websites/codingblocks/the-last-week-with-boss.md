---
title: "The Last Week with BOSS"
date: "2017-08-06T22:43:00.000Z"
slug: "the-last-week-with-boss"
image: "https://blog.codingblocks.com/content/images/2019/01/pexels-photo-136320-1.jpeg"
description: "Hello, Everyone!  I am Arushi Singhal. BTech Undergraduate student at International Institute of Information Technology, Hyderabad.  To all the mentors and contributors, this week is the last week with BOSS, yes you heard it right, the very last week of the program.  The three-month long program is finally coming to"
tags: []
original_url: "https://blog.codingblocks.com/2017/the-last-week-with-boss/"
---

Hello, Everyone!  
I am Arushi Singhal. BTech Undergraduate student at International Institute of Information Technology, Hyderabad.

To all the mentors and contributors, this week is the last week with BOSS, yes you heard it right, the very last week of the program.

The three-month long program is finally coming to its end :(. It's being the great journey with BOSS and I have been amazed and humbled by the efforts being put in by mentors in guiding us throughout the program and also to the contributors for making this program a success.

I will take many fond memories from the program and hope that the other contributors feel the same.  
The flexibility of choosing any project for contribution at any time and also no timeline constraint makes BOSS program unique and great from other such programs.

My start at BOSS was incredible since I felt a lot the ownership for my work. Facing challenges such as learning new frameworks or understanding the documentation have ultimately been positive experiences -- this makes me feel more and more like a developer. Please have a look at my previous [blog](https://blog.codingblocks.com/2017/beginning-with-open-source) for reading about my Beginning Experience with BOSS.

![121212_2_OpenSwissKnife-2](https://blog.codingblocks.com/content/images/2019/01/121212_2_OpenSwissKnife-2.png)

I would like to thank BOSS for giving Indian developers this opportunity to get experienced with Open source and become contributors. With BOSS I experienced different-different phases of development from designing logos for software, finding bugs, to write code. BOSS gave me chance to develop my skills in every phase of development.

I want to end my blog by writing the key rule for contribution in OpenSource: "Don’t get disappointed or feel dejected if your pull request is not merged at once, it opens up the gate to learning when you work through the suggestions provided by the mentors as they know how the pull request can be improved."

Once more I would like to thank BOSS program for making my summer productive and great.

Cheers to all the mentors and contributors.  
Congratulations to all the winners of the program in advance.  
BOSS, see you again soon next Summer :).