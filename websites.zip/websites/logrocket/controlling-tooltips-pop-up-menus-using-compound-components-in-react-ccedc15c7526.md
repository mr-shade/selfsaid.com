---
title: "Controlling tooltips & pop-up menus with components in React - LogRocket Blog"
date: "2021-02-01T14:00:24+00:00"
slug: "controlling-tooltips-pop-up-menus-using-compound-components-in-react-ccedc15c7526"
image: "https://blog.logrocket.com/wp-content/uploads/2019/01/1_RL8EObVPvcNzqLtDvkgl2A.jpeg"
description: "Use compound components to control tooltips and pop-up menus in your React applications, helping you keep your user interface clean and tidy."
tags: []
original_url: "https://blog.logrocket.com/controlling-tooltips-pop-up-menus-using-compound-components-in-react-ccedc15c7526/"
---

![](https://secure.gravatar.com/avatar/407e8a1e84ad45b978a8d44a1ed7f9ee02b5693ed1157fccfe71b6710706023a?s=36&d=mm&r=g) **tae** says:

[February 2, 2020 at 9:28 pm](https://blog.logrocket.com/controlling-tooltips-pop-up-menus-using-compound-components-in-react-ccedc15c7526/#comment-1483)

Thank you for sharing! that’s very informative.

[Reply](#comment-1483)