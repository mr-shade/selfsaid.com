---
title: "Getting started with Vuetify: Is Vuetify right for you? - LogRocket Blog"
date: "2022-08-18T02:00:16+00:00"
slug: "getting-started-is-vuetify-right-for-you"
image: "https://blog.logrocket.com/wp-content/uploads/2021/08/vuetify-.png"
description: "Learn how Vuetify works and weigh its pros and cons by creating a simple, responsive, Material-based page from scratch."
tags: []
original_url: "https://blog.logrocket.com/getting-started-is-vuetify-right-for-you/"
---

![](https://secure.gravatar.com/avatar/ccdbfca14ad87cc309d5ac2905e15002192dfdf411a3ad7a8d8bf78943fecabb?s=36&d=mm&r=g) **Dirk** says:

[September 4, 2021 at 2:50 am](https://blog.logrocket.com/getting-started-is-vuetify-right-for-you/#comment-8162)

The code and description lacks the changes made in VuetifyJs considering the layout.

[Reply](#comment-8162)