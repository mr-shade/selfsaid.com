---
title: "Making the business case for React in 2019 - LogRocket Blog"
date: "2019-04-03T02:00:30+00:00"
slug: "making-the-business-case-for-react-in-2019-74463bbb22de"
image: "https://storage.googleapis.com/blog-images-backup/1*FcQPFvjIFgg54PdR3y5P_w.jpeg"
description: "React is the world’s most popular JavaScript framework. Of course, the only way to gauge actual usage of an open […]"
tags: []
original_url: "https://blog.logrocket.com/making-the-business-case-for-react-in-2019-74463bbb22de/"
---

![](https://secure.gravatar.com/avatar/89ad37ea70c73c3bb88377ce65812f019ae4ee78ba5ac435fdb0da9da604824a?s=36&d=mm&r=g) **Pawel Psztyc** says:

[April 9, 2020 at 2:39 pm](https://blog.logrocket.com/making-the-business-case-for-react-in-2019-74463bbb22de/#comment-2084)

You can’t compare market share and # of download of a library. React is used by high traffic websites with a large dev groups that work on the project all the time. That drives downloads on NPM. But it has nothing to do with market share. The actual data shows market share is 0.3% (April 2020) [https://w3techs.com/technologies/details/js-react](https://w3techs.com/technologies/details/js-react)

[Reply](#comment-2084)