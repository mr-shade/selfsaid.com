---
title: "Testing Node.js with Mocha and Chai - LogRocket Blog"
date: "2022-07-13T16:00:25+00:00"
slug: "testing-node-js-mocha-chai"
image: "https://blog.logrocket.com/wp-content/uploads/2020/11/node-mocha.png"
description: "Commonly used with Chai, Mocha is an open source JavaScript testing framework that runs on Node.js and in the browser."
tags: []
original_url: "https://blog.logrocket.com/testing-node-js-mocha-chai/"
---

![](https://secure.gravatar.com/avatar/cb7b5adaa7e61502734eca69409dc16e412569d78dc838ce6fc5dd6079e450ea?s=36&d=mm&r=g) **Davit** says:

[May 5, 2020 at 11:43 am](https://blog.logrocket.com/testing-node-js-mocha-chai/#comment-2345)

this line var sum = require(‘../sum’); must be var sum = require(‘../sum.js’);

[Reply](#comment-2345)