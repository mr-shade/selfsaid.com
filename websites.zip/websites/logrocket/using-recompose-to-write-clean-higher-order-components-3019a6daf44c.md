---
title: "Using Recompose to write clean higher-order components - LogRocket Blog"
date: "2018-06-26T02:00:17+00:00"
slug: "using-recompose-to-write-clean-higher-order-components-3019a6daf44c"
image: "https://blog.logrocket.com/wp-content/uploads/2018/06/using-recompose-write-clean-hocs.png"
description: "Learn how Recompose methods can help create cleaner HOCs and how it simplifies the development and organization of React components."
tags: []
original_url: "https://blog.logrocket.com/using-recompose-to-write-clean-higher-order-components-3019a6daf44c/"
---

![](https://secure.gravatar.com/avatar/0e7755dec375e77f59e180a2a9b128f2ff8f82541e4bb35140df63a0cbee2d84?s=36&d=mm&r=g) **Mike Bee** says:

[November 23, 2019 at 6:27 pm](https://blog.logrocket.com/using-recompose-to-write-clean-higher-order-components-3019a6daf44c/#comment-991)

Excellent article JuamMa and good examples. However, I think you may have forgot to change the code for withHandlerClick.js, as it looks the same as withStateTimes.js unless I have misread it…

[Reply](#comment-991)