---
title: "Using web workers for safe, concurrent JavaScript - LogRocket Blog"
date: "2018-03-26T22:00:41+00:00"
slug: "using-webworkers-for-safe-concurrent-javascript-3f33da4eb0b2"
image: "https://blog.logrocket.com/wp-content/uploads/2018/03/using-web-workers-safe-concurrent-javascript-nocdn.jpg"
description: "Web workers provide a way to run JavaScript code outside the single thread of execution in the browser. The single […]"
tags: []
original_url: "https://blog.logrocket.com/using-webworkers-for-safe-concurrent-javascript-3f33da4eb0b2/"
---

![](https://secure.gravatar.com/avatar/95c6025594857503147c45c9bae3513ad93a5413447eb9ed495ea4bf393090ca?s=36&d=mm&r=g) **Максим Куклин** says:

[July 18, 2019 at 1:34 am](https://blog.logrocket.com/using-webworkers-for-safe-concurrent-javascript-3f33da4eb0b2/#comment-188)

Cool, thanks

[Reply](#comment-188)