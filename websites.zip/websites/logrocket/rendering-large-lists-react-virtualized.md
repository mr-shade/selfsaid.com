---
title: "Rendering large lists with React Virtualized - LogRocket Blog"
date: "2023-03-01T17:00:23+00:00"
slug: "rendering-large-lists-react-virtualized"
image: "https://blog.logrocket.com/wp-content/uploads/2018/05/rendering-large-lists-react-virtualized.png"
description: "Use the react-virtualized library to display thousands of rows of data without sacrificing usability or slowing down your web page."
tags: []
original_url: "https://blog.logrocket.com/rendering-large-lists-react-virtualized/"
---

![](https://secure.gravatar.com/avatar/77b9b2998012aa654f90ba0a1920e6393c6e156f8635db347a710dcc727cbeaa?s=36&d=mm&r=g) **[Gustavo](https://azship.com.br)** says:

[August 12, 2019 at 6:07 pm](https://blog.logrocket.com/rendering-large-lists-react-virtualized/#comment-342)

As always great tutorial guys!

[Reply](#comment-342)