---
title: "A tutorial on creating coding tutorials - LogRocket Blog"
date: "2018-04-17T22:00:17+00:00"
slug: "a-tutorial-on-creating-front-end-tutorials-2b13d8e94df9"
image: "https://storage.googleapis.com/blog-images-backup/1*1jzYwqp2s6_j_vAnMMz0QQ.jpeg"
description: "So you’ve just implemented an offbeat and interesting solution to a particular coding problem. You’re pumped. You decide to create […]"
tags: []
original_url: "https://blog.logrocket.com/a-tutorial-on-creating-front-end-tutorials-2b13d8e94df9/"
---

![](https://graph.facebook.com/v2.9/10158032506441264/picture?type=large&_md5=d0a1969d88b885f5168cfa0d38458f24) **Meera Menon** says:

[October 10, 2019 at 3:06 am](https://blog.logrocket.com/a-tutorial-on-creating-front-end-tutorials-2b13d8e94df9/#comment-680)

Hullo Sir, that was an amazing article! It was so encouraging and true…In fact, several times I have noticed this ego issue with senior dev who even answer questions with an all too obvious sneer, thereby making the situation awkward for the person who posted the question or doubt! Yes, while writing or shooting tutorials, developers must have a teacher’s perspective in mind, that of helping out students in need of help and solving some information gap.with their knowledge, rather than show off their seniority in terms of knowledge or certifications or experience etc.  
I have a small question to ask here. In case of creating video tutorials, is it a better idea to narrate while typing out the code for the entire session, or present the code with the output and then narrate the code step by step? I am so confused , hence asking. Thanks.

[Reply](#comment-680)