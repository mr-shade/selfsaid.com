---
title: "Promise chaining is dead. Long live async/await - LogRocket Blog"
date: "2018-11-14T22:00:20+00:00"
slug: "promise-chaining-is-dead-long-live-async-await-445897870abc"
image: "https://storage.googleapis.com/blog-images-backup/1*g4lmTSnkQrovZDS0JfrsbA.png"
description: "​​While async functions have been around forever, they are often left untouched. Async/await is what some may consider an outcast. […]"
tags: []
original_url: "https://blog.logrocket.com/promise-chaining-is-dead-long-live-async-await-445897870abc/"
---

![](https://secure.gravatar.com/avatar/cbfef7796ff4ef0d8f22afc47669b9031892d41fdcbeb8ea2bfb71577eebae08?s=36&d=mm&r=g) **samo794** says:

[August 21, 2019 at 6:47 am](https://blog.logrocket.com/promise-chaining-is-dead-long-live-async-await-445897870abc/#comment-384)

well written, thanks

[Reply](#comment-384)