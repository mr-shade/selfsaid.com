---
title: "How CSS works: Understanding the cascade - LogRocket Blog"
date: "2018-05-30T02:00:20+00:00"
slug: "how-css-works-understanding-the-cascade-d181cd89a4d8"
image: "https://blog.logrocket.com/wp-content/uploads/2018/05/1_diR0Ma4Z8nsdH1Kvn53qbA-1.jpeg"
description: "A few weeks back I got to start a short series on CSS fundamentals. If you’re in the front-end web […]"
tags: []
original_url: "https://blog.logrocket.com/how-css-works-understanding-the-cascade-d181cd89a4d8/"
---

![](https://secure.gravatar.com/avatar/f70c5ffe04292fbfaf9d5a124f37bf83e2705d1ed7d674e534a4d213b0624c01?s=36&d=mm&r=g) **Jared** says:

[April 12, 2020 at 7:20 pm](https://blog.logrocket.com/how-css-works-understanding-the-cascade-d181cd89a4d8/#comment-2104)

Great article! For so many years I have also, always assumed that the term ‘cascade’ was referring to, what is in fact – inheritance! And I’d bet 90% of devs also make the same mistake.  
Perhaps the choice of that particular word to describe the process of conflict resolution could have been better.

[Reply](#comment-2104)