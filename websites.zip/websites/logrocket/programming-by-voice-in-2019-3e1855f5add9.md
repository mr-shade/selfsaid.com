---
title: "Programming by voice in 2019 - LogRocket Blog"
date: "2019-04-16T02:00:48+00:00"
slug: "programming-by-voice-in-2019-3e1855f5add9"
image: "https://blog.logrocket.com/wp-content/uploads/2019/04/programming-by-voice-2019.png"
description: "Some software developers may not have the full use of their hands, whether due to a condition like carpal tunnel […]"
tags: []
original_url: "https://blog.logrocket.com/programming-by-voice-in-2019-3e1855f5add9/"
---

![](https://secure.gravatar.com/avatar/6ce07928ff84e26ea57a16388767438d648a811d18d466a928f473a4e1106eeb?s=36&d=mm&r=g) **rajshri** says:

[December 31, 2019 at 2:18 am](https://blog.logrocket.com/programming-by-voice-in-2019-3e1855f5add9/#comment-1236)

i would like to work on this topic …as i m looking for research topic n it seems interesting to work on such topic…i would like to use nlp/nlg techniques for research

[Reply](#comment-1236)