---
title: "The state of React Native for Web - LogRocket Blog"
date: "2019-04-11T02:00:46+00:00"
slug: "the-state-of-react-native-web-in-2019-6ab67ac5c51e"
image: "https://blog.logrocket.com/wp-content/uploads/2019/04/state-of-react-native-web.jpeg"
description: "Creating universal apps was a dream that came true with React Native for Web, but there are still some gaps to fill."
tags: []
original_url: "https://blog.logrocket.com/the-state-of-react-native-web-in-2019-6ab67ac5c51e/"
---

![](https://secure.gravatar.com/avatar/9ea457757a77724d2861a466eb462f9b1c61231da5c20235b3582651d006a9fa?s=36&d=mm&r=g) **Alex Stanbury** says:

[June 6, 2019 at 6:03 am](https://blog.logrocket.com/the-state-of-react-native-web-in-2019-6ab67ac5c51e/#comment-34)

Nice article. Microsoft have created ReactXP which provides an abstract layer over RN and ReactJS, I’ve just started using it and the documentation is a bit lean but it’s proving to be a pretty good experience so far.

[https://github.com/microsoft/reactxp](https://github.com/microsoft/reactxp)

[Reply](#comment-34)