---
title: "A complete guide for leveling up your CSS selector skills - LogRocket Blog"
date: "2021-07-02T02:00:45+00:00"
slug: "level-up-your-css-selector-skills"
image: "https://blog.logrocket.com/wp-content/uploads/2018/06/1_c-SHpWHyrJ2ozRbqI2U5sQ.jpeg"
description: "Think you know your CSS selectors? Check out this in-depth review of different CSS selectors (including some you've never heard of)."
tags: []
original_url: "https://blog.logrocket.com/level-up-your-css-selector-skills/"
---

![](https://secure.gravatar.com/avatar/bf62cb33b0507d5b4618970f3f8ecdc8b8ec64a7811064de1b80736b482f88b7?s=36&d=mm&r=g) **WoodyP** says:

[April 12, 2022 at 2:54 am](https://blog.logrocket.com/level-up-your-css-selector-skills/#comment-20846)

Hello,  
did you get to read my message?  
Thanking you for your amazing article, I have a question, how to style the level-1 items of a level-0 “tr” menu.  
I sent a screenshot showing the admin menu of the WordPress categories.

Thanks!

[Reply](#comment-20846)