---
title: "When to use HTML5’s canvas - LogRocket Blog"
date: "2019-04-09T02:00:15+00:00"
slug: "when-to-use-html5s-canvas-ce992b100ee8"
image: "https://storage.googleapis.com/blog-images-backup/1*sQuSbqYHW-38cJXo3RsvWA.png"
description: "The HTML5 canvas has the potential to become a staple of the web, enjoying ubiquitous browser and platform support in […]"
tags: []
original_url: "https://blog.logrocket.com/when-to-use-html5s-canvas-ce992b100ee8/"
---

![](https://secure.gravatar.com/avatar/f40d17e3806c6d5b25d1820e701394cc573cc5927d2b8eb897ba2952a5293fe8?s=36&d=mm&r=g) **Dave** says:

[April 28, 2021 at 4:21 pm](https://blog.logrocket.com/when-to-use-html5s-canvas-ce992b100ee8/#comment-6602)

EaselJS is no longer maintained – the last release was in 2017

[Reply](#comment-6602)