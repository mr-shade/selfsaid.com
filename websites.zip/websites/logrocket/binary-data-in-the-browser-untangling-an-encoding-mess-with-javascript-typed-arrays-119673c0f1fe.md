---
title: "Binary data in the browser: Untangling an encoding mess with JavaScript Typed Arrays - LogRocket Blog"
date: "2018-05-23T02:00:23+00:00"
slug: "binary-data-in-the-browser-untangling-an-encoding-mess-with-javascript-typed-arrays-119673c0f1fe"
image: "https://storage.googleapis.com/blog-images-backup/1*MPpfSHYOlpIBcdaPQXBBRQ.png"
description: "Face the black magic of working with binary data on the web with JavaScript Typed Arrays, giving you the control you need over your data in the browser."
tags: []
original_url: "https://blog.logrocket.com/binary-data-in-the-browser-untangling-an-encoding-mess-with-javascript-typed-arrays-119673c0f1fe/"
---

![](https://secure.gravatar.com/avatar/0591886745ba16e655d7bb990e245b4828aadafb94d33122b23d2f42d3bdb71a?s=36&d=mm&r=g) **[Bill F.](https://bf-s.co)** says:

[March 10, 2023 at 7:36 am](https://blog.logrocket.com/binary-data-in-the-browser-untangling-an-encoding-mess-with-javascript-typed-arrays-119673c0f1fe/#comment-33925)

thanks for this excellent account of your troubles with binary data in javascript strings… it’s quite thorough and enlightening!

[Reply](#comment-33925)