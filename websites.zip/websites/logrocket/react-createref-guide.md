---
title: "How to use React createRef - LogRocket Blog"
date: "2022-11-15T15:00:30+00:00"
slug: "react-createref-guide"
image: "https://blog.logrocket.com/wp-content/uploads/2020/12/react-createref-guide.png"
description: "Learn how to use the React.createRef() method and useRef Hook in React to simplify creating refs and interact with the HTML DOM."
tags: []
original_url: "https://blog.logrocket.com/react-createref-guide/"
---

![](https://secure.gravatar.com/avatar/d53b6afcc07cb88bad73b5d9494898fb330bc893bed4b6f2158e15f2a53b1af5?s=36&d=mm&r=g) **Abid** says:

[August 22, 2019 at 3:51 am](https://blog.logrocket.com/react-createref-guide/#comment-388)

Pretty informative article on refs. I would suggest you update the article about creating refs with hooks, since its available with React 16.8.6 and above.

[Reply](#comment-388)