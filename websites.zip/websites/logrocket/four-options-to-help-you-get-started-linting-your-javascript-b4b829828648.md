---
title: "4 options to help you get started linting your JavaScript - LogRocket Blog"
date: "2018-08-21T22:00:25+00:00"
slug: "four-options-to-help-you-get-started-linting-your-javascript-b4b829828648"
image: "https://storage.googleapis.com/blog-images-backup/1*GPjaPKNNUYHU8EsA3Z0JGA.png"
description: "Searching for tools to refine your linting process? JSLint, standardJS, JSHint, and ESLint are reliable, built-in editor options to get you started."
tags: []
original_url: "https://blog.logrocket.com/four-options-to-help-you-get-started-linting-your-javascript-b4b829828648/"
---

![](https://secure.gravatar.com/avatar/082323a0be908b1d8282345b1dcb52dcc775592811b3bf72508abd4ce8a39412?s=36&d=mm&r=g) **neil** says:

[December 31, 2020 at 5:13 am](https://blog.logrocket.com/four-options-to-help-you-get-started-linting-your-javascript-b4b829828648/#comment-4764)

Ok, great overview..  
However, I wasted a few hours trying to figure out why the cmd to create the config file  
$ ./node\_modules/.bin/eslint –init  
was NOT WORKING; Turns out this is another case of authors on Linux typically ignoring their Windows readers. Use backslashes if you are a Windows user and it will work for you. Don’t waste a few hours of your life like I did !

[Reply](#comment-4764)