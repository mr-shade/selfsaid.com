---
title: "Lazy loading React components - LogRocket Blog"
date: "2020-11-11T17:00:24+00:00"
slug: "lazy-loading-components-in-react-16-6-6cea535c0b52"
image: "https://blog.logrocket.com/wp-content/uploads/2018/10/react-lazy-loading.png"
description: "Learn how to apply code-splitting and lazy loading to React components with React.lazy() and React.Suspense."
tags: []
original_url: "https://blog.logrocket.com/lazy-loading-components-in-react-16-6-6cea535c0b52/"
---

![](https://secure.gravatar.com/avatar/4078577a709de93c8c86db946b1b85fef5842c9a807ee5480a6939689d83c524?s=36&d=mm&r=g) **[Devin](http://devinpapaya.com)** says:

[June 17, 2019 at 10:48 am](https://blog.logrocket.com/lazy-loading-components-in-react-16-6-6cea535c0b52/#comment-67)

Is there a reason for using @reach over react-router?

[Reply](#comment-67)