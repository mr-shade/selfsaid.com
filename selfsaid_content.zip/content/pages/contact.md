---
title: "Contact Us"
date: "2024-03-20"
description: "Get in touch with the Self Said team."
featured_image: "/images/og-default.jpg"
tags: ["Contact"]
---

## We'd Love to Hear From You

Whether you have a suggestion for a new topic, a question about our content, or just want to say hello, we're here to listen.

### General Inquiries

For general questions and feedback, please email us at:
**hello@selfsaid.30tools.com**

### Partnerships

For advertising and partnership opportunities, please reach out to:
**partners@selfsaid.30tools.com**

### Follow Us

Stay connected on social media for daily updates and inspiration.
