---
title: "Privacy Policy"
date: "2024-03-20"
description: "Our commitment to protecting your privacy."
featured_image: "/images/og-default.jpg"
tags: ["Legal"]
---

**Last Updated: March 20, 2024**

At Self Said, we take your privacy seriously. This Privacy Policy describes how your personal information is collected, used, and shared when you visit or make a purchase from our site.

## key Information

*   **We do not sell your data.**
*   **We use cookies** to improve your browsing experience and analyze site traffic.
*   **You can opt-out** of marketing communications at any time.

For full details or to make a data request, please contact us at privacy@selfsaid.30tools.com.
