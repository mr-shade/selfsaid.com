---
title: Madonna’s Best Quotes
date: '2024-06-13T11:14:34+02:00'
author: Seff Bray
description: >-
  Discover the wisdom of Madonna with this compilation of her most significant
  and inspiring quotes.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/Madonna-Quotes.webp'
original_url: 'https://selfsaid.30tools.com/madonna-quotes/'
---

![](https://seffsaid.com/wp-content/uploads/Madonna-Quotes.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

Madonna has been a cultural icon for decades, and her words often reflect her bold personality and unapologetic attitude. Below, you’ll find some of her best quotes that capture her unique perspective and wisdom. Read more [quotes from famous people](https://selfsaid.30tools.com/quotes-by-famous-people) here.

## 50 Madonna Quotes

1.  “I’m tough, I’m ambitious, and I know exactly what I want. If that makes me a bitch, okay.” — Madonna
2.  “Poor is the man whose pleasures depend on the permission of another.” — Madonna
3.  “To me, the whole process of being a brush stroke in someone else’s painting is a little difficult.” — Madonna
4.  “A lot of people are afraid to say what they want. That’s why they don’t get what they want.” — Madonna
5.  “I am my own experiment. I am my own work of art.” — Madonna
6.  “Sometimes you have to be a bitch to get things done.” — Madonna
7.  “I stand for freedom of expression, doing what you believe in, and going after your dreams.” — Madonna
8.  “Everyone needs to be valued. Everyone has the potential to give something back.” — Madonna
9.  “I’m not interested in being Wonder Woman in the delivery room. Give me drugs.” — Madonna
10.  “I’m tough, ambitious, and I know exactly what I want.” — Madonna
11.  “Better to live one year as a tiger, than a hundred as a sheep.” — Madonna
12.  “We all have our own personal challenges. It’s about how you overcome them and use them to your advantage.” — Madonna
13.  “Express yourself, don’t repress yourself.” — Madonna
14.  “I think the ultimate challenge is to have some kind of style and grace, even when you’re going through something difficult.” — Madonna
15.  “I’m not religious, but I’m very spiritual.” — Madonna
16.  “I always felt a vulnerability about being an artist and not being able to show what I’m really made of.” — Madonna
17.  “The most important thing is to have a sense of responsibility, commitment, and respect.” — Madonna
18.  “I always thought I should be treated like a star.” — Madonna
19.  I want to be like Gandhi and [Martin Luther King](https://selfsaid.30tools.com/martin-luther-king-quotes) and [John Lennon](https://selfsaid.30tools.com/john-lennon-quotes), but I want to stay alive.” — Madonna
20.  “My work is a reflection of my soul.” — Madonna
21.  “I won’t be happy till I’m as famous as God.” — Madonna
22.  “I’m a very disciplined person when it comes to working out.” — Madonna
23.  “Power is being told you’re not loved and not being destroyed by it.” — Madonna
24.  “I think of myself as a soldier.” — Madonna
25.  “The worst thing about being famous? The press.” — Madonna
26.  “I have the same goal I’ve had ever since I was a girl. I want to rule the world.” — Madonna
27.  “I wouldn’t have turned out the way I was if I didn’t have all those old-fashioned values to rebel against.” — Madonna
28.  “I’m my own worst enemy. I’m not who I’m meant to be.” — Madonna
29.  “I have the strength of a bull, but I have the heart of a rabbit.” — Madonna
30.  “The best thing about being a mom is that it definitely keeps you grounded.” — Madonna
31.  “Art is sacred. Punk rock means freedom.” — Madonna
32.  “Fame is not something I take seriously.” — Madonna
33.  “In this business, you can be all washed up in a year.” — Madonna
34.  “I am because we are. We all bleed the same color. We all want to love and be loved.” — Madonna
35.  “I always thought I should be treated like a queen.” — Madonna
36.  “I feel just as hungry today as I did the day I left home.” — Madonna
37.  “I want to be the best. I want to be number one.” — Madonna
38.  “I always had a lot of confidence in my music. I felt it was groundbreaking.” — Madonna
39.  “I think scars are like battle wounds — beautiful, in a way. They show what you’ve been through and how strong you are for coming out of it.” — Madonna
40.  “Only when I’m dancing can I feel this free.” — Madonna
41.  “A lot of people are afraid to be honest. It’s like being naked.” — Madonna
42.  “I always feel better after I work out.” — Madonna
43.  “I don’t trust anyone who’s nice to me just because I am a celebrity.” — Madonna
44.  “I’m an artist, and I can be as egotistical as I want to be.” — Madonna
45.  “I have the same goal I’ve had ever since I was a girl. I want to rule the world.” — Madonna
46.  “If it’s bitter at the start, then it’s sweeter in the end.” — Madonna
47.  “A woman’s destiny, they say, is not fulfilled until she holds in her arms her own little book.” — Madonna
48.  “I’d like to think I can make an impact in the world through my music.” — Madonna
49.  “I think that everyone should get married at least once, so you can see what a silly, outdated institution it is.” — Madonna
50.  “I want to be remembered as a revolutionary who triggered an explosion of human imagination and creativity.” — Madonna

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fmadonna-quotes%2F)

[Pin2](https://pinterest.com/pin/create/button/?url=/madonna-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2FMadonna-Quotes-PIN.jpg&description=Discover+the+wisdom+of+Madonna+with+this+compilation+of+her+most+significant+and+inspiring+quotes.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=Madonna%27s+Best+Quotes&url=https%3A%2F%2Fselfsaid.30tools.com%2Fmadonna-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fmadonna-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fmadonna-quotes%2F)

[More](#)

2 Shares

Source: https://selfsaid.30tools.com/madonna-quotes/
