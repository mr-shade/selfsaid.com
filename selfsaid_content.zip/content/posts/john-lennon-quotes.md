---
title: '50 John Lennon Quotes On Peace, Life and Love'
date: '2024-03-07T12:26:48+01:00'
author: Seff Bray
description: >-
  Let these John Lennon quotes inspire your day and influence your thoughts on
  peace, love, and life.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/John-Lennon-Quotes.webp'
original_url: 'https://selfsaid.30tools.com/john-lennon-quotes/'
---

![John Lennon with a guitar over his shoulder walking down a deserted road.](https://seffsaid.com/wp-content/uploads/John-Lennon-Quotes.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

While there are many lists of [Beatles quotes](https://selfsaid.30tools.com/beatles-quotes) out there, the most memorable ones are probably attributed to John Lennon. His words on peace, life, and love continue to resonate with people across the world, decades after they were first spoken.

Lennon had a unique way of expressing complex ideas in a straightforward manner, making his quotes not just memorable, but also relatable. Whether you’re a die-hard Beatles fan or just someone in search of a little inspiration, Lennon’s wisdom has something for everyone.

1.  Life is what happens to you while you’re busy making other plans.” – John Lennon
2.  “A dream you dream alone is only a dream. A dream you dream together is reality.” – John Lennon
3.  “Time you enjoy wasting, was not wasted.” – John Lennon
4.  “Reality leaves a lot to the imagination.” – John Lennon
5.  “You may say I’m a dreamer, but I’m not the only one. I hope someday you’ll join us. And the world will live as one.” – John Lennon
6.  “War is over if you want it.” – John Lennon
7.  “[Life is short](https://selfsaid.30tools.com/the-26-best-short-life-quotes), and there’s no time for fussing and fighting, my friends.” – John Lennon
8.  “When you’re drowning, you don’t say ‘I would be incredibly pleased if someone would have the foresight to notice me drowning and come and help me,’ you just scream.” – John Lennon
9.  “Being honest may not get you a lot of friends but it’ll always get you the right ones.” – John Lennon
10.  “Count your age by friends, not years. Count your life by smiles, not tears.” – John Lennon
11.  “There are no problems, only solutions.” – John Lennon
12.  “Love is the answer, and you know that for sure; Love is a flower, you’ve got to let it grow.” – John Lennon
13.  “[Everything will be ok](https://selfsaid.30tools.com/everything-will-be-ok-quotes) in the end. If it’s not ok, it’s not the end.” – John Lennon
14.  “Peace is not something you wish for; It’s something you make, something you do, something you are, and something you give away.” – John Lennon
15.  “Life is what happens when you are busy making other plans.” – John Lennon
16.  “If everyone demanded peace instead of another television set, then there’d be peace.” – John Lennon
17.  “The more I see, the less I know for sure.” – John Lennon
18.  “It doesn’t matter how long my hair is or what colour my skin is or whether I’m a woman or a man.” – John Lennon
19.  “Art is only a way of expressing pain.” – John Lennon
20.  “Happiness is just how you feel when you don’t feel miserable.” – John Lennon
21.  “The more real you get the more unreal the world gets.” – John Lennon
22.  “I don’t believe in yesterday, by the way.” – John Lennon
23.  “If someone thinks that love and peace is a cliché that must have been left behind in the Sixties, that’s his problem. Love and peace are eternal.” – John Lennon
24.  “I’m not going to change the way I look or the way I feel to conform to anything. I’ve always been a freak. So I’ve been a freak all my life and I have to live with that, you know. I’m one of those people.” – John Lennon
25.  “We live in a world where we have to hide to make love, while violence is practiced in broad daylight.” – John Lennon
26.  “There’s nothing you can know that isn’t known.” – John Lennon
27.  Imagine all the people [living life](https://selfsaid.30tools.com/live-life-to-the-fullest) in peace. You may say I’m a dreamer, but I’m not the only one. I hope someday you’ll join us, and the world will be as one.” – John Lennon
28.  “We’re more popular than Jesus now; I don’t know which will go first – rock ‘n’ roll or Christianity.” – John Lennon
29.  “I believe in everything until it’s disproved. So I believe in fairies, the myths, dragons. It all exists, even if it’s in your mind. Who’s to say that dreams and nightmares aren’t as real as the here and now?” – John Lennon
30.  “A working class hero is something to be.” – John Lennon
31.  “The postman’s fear of dogs is much exaggerated.” – John Lennon
32.  “Our society is run by insane people for insane objectives. I think we’re being run by maniacs for maniacal ends and I think I’m liable to be put away as insane for expressing that. That’s what’s insane about it.” – John Lennon
33.  “You don’t need anybody to tell you who you are or what you are. You are what you are!” – John Lennon
34.  “Everybody loves you when you’re six foot in the ground.” – John Lennon
35.  “I get by with a little help from my friends.” – John Lennon
36.  “I’m not afraid of death because I don’t believe in it. It’s just getting out of one car, and into another.” – John Lennon
37.  “If you want peace, you won’t get it with violence.” – John Lennon
38.  “Part of me suspects that I’m a loser, and the other part of me thinks I’m God Almighty.” – John Lennon
39.  “God is a concept by which we measure our pain.” – John Lennon
40.  “The government’s a joke. The only thing real is you and me.” – John Lennon
41.  “You either get tired fighting for peace, or you die.” – John Lennon
42.  “I’m not really a career person; I’m a gardener, basically.” – John Lennon
43.  “All we are saying is give peace a chance.” – John Lennon
44.  “I don’t believe in killing whatever the reason!” – John Lennon
45.  “Nobody controls me. I’m uncontrollable. The only one who controls me is me, and that’s just barely possible.” – John Lennon
46.  “Music is everybody’s possession. It’s only publishers who think that people own it.” – John Lennon
47.  “We need to learn to love ourselves first, in all our glory and our imperfections.” – John Lennon
48.  “The best things in life are free, but you can keep them for the birds and bees. Now give me money.” – John Lennon
49.  “Limitless undying love which shines around me like a million suns, it calls me on and on across the universe.” – John Lennon
50.  “You have to be a bastard to make it, and that’s a fact.” – John Lennon

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fjohn-lennon-quotes%2F)

[Pin75](https://pinterest.com/pin/create/button/?url=/john-lennon-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2FJohn-Lennon-Quotes-PIN.jpg&description=Let+these+John+Lennon+quotes+inspire+your+day+and+influence+your+thoughts+on+peace%2C+love%2C+and+life.++via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=50+John+Lennon+Quotes+On+Peace%2C+Life+and+Love&url=https%3A%2F%2Fselfsaid.30tools.com%2Fjohn-lennon-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fjohn-lennon-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fjohn-lennon-quotes%2F)

[More](#)

75 Shares

Source: https://selfsaid.30tools.com/john-lennon-quotes/
