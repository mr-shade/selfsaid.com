---
title: 38 Very Short Quotes About Life
date: '2024-06-13T11:43:06+02:00'
author: Seff Bray
description: >-
  Discover 38 of the best short quotes about life that will fill you with wisdom
  and inspiration.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/Very-Short-Quotes-About-Life.webp'
original_url: 'https://selfsaid.30tools.com/38-very-short-quotes-about-life/'
---

![](https://seffsaid.com/wp-content/uploads/Very-Short-Quotes-About-Life.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

Many people have a favorite motivational or inspirational quote. A quote that speaks or resonates with them personally. But why is this? How can a few words have such a profound effect on so many people? Well, a [powerful quote](https://selfsaid.30tools.com/martin-luther-king-quotes) can be like a close friend, a mentor, or a personal coach offering personalized advice or encouragement when you need it the most.

In [difficult times](https://selfsaid.30tools.com/quotes-about-being-strong) or when experiencing periods of self-doubt, inspirational quotes can be just what you need to clear your head of negative thoughts and motivate you to start moving ahead with your life. And quotes don’t have to be overly long and complicated, some of the shortest quotes can say so much.

So, if you are in need of a pick me up, here’s a collection of extremely powerful very short quotes about life that will stir you, fill you with wisdom and inspiration, and help keep you motivated throughout the day. I hope you enjoy them.

1\. “Every moment matters.” – Unknown

2\. “Different doesn’t matter.” – Unknown

3\. “Collect moments, not things” – Unknown

4\. “Worry less, smile more.” – Unknown

5\. “Aspire to inspire before we expire.” – Eugene Bell Jr.

6\. “Prove them wrong.” – Unknown

7\. “Dream without fear. Love without limits.” – Dilip Bathija

8\. “Broken crayons still color.” – Unknown

9\. “[Be a warrior](https://selfsaid.30tools.com/unleashing-your-inner-warrior), not a worrier.” – Unknown

11\. “Don’t stop until you’re proud.” – Unknown

10\. “Find a way or make one.” – Unknown

12\. Freedom is a [state of mind.”](https://selfsaid.30tools.com/how-i-cultivated-a-focused-state-of-mind) – Walter Mosley

13\. “Die with memories, not dreams.” – Unknown

14\. “When nothing goes right, go left.” – Martha Cecilia

15\. “You are your only limit.” – Unknown

16\. “Doubt kills more dreams than failure ever will.” – Suzy Kassem

17\. “Do it with passion or not at all.” – Rosa Nochette Carey

18\. “Think like a proton. [Always positive.”](https://selfsaid.30tools.com/always-keep-a-positive-mindset) – Unknown

19\. “Fate loves the fearless.” – James Russell Lowell

20\. “Mistakes are proof that you are trying.” – Jennifer Lim

21\. “Conquer from within.” – Unknown

22\. “Enjoy the little things.” – Unknown

23\. “If you never try, you’ll never know.” – Unknown

24\. “Difficult roads often lead to beautiful destinations.” – Zig Ziglar

25\. “Don’t count the days, make the days count.” – Muhammad Ali

26\. “It is not the length of life, but the depth.” – Ralph Waldo Emerson

27\. “Enjoy the little things.” – Unknown

28\. “I am too full of life to be half loved.” – Ijeoma Umebinyuo

29\. “Make it happen.” – Unknown

30\. “Do what you love.” – Unknown

31\. “Let life surprise you.” – Unknown

32\. “Nothing worth having comes easy.” – Theodore Roosevelt

33\. “The best is yet to come.” – Unknown

34\. “Don’t be afraid to dream big.” – Unknown

35\. “Having hope will give you courage.” – Job 11:18

36\. Great things never came from [comfort zones.”](https://selfsaid.30tools.com/50-best-comfort-zone-quotes) – Roy T. Bennett

37\. “I don’t know where I am going but I am on my way.” – Voltaire

38\. “Dreams don’t work unless you do.” – John C. Maxwell

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2F38-very-short-quotes-about-life%2F)

Pin2.17K

[Tweet](https://twitter.com/intent/tweet?text=38+very+short+powerful+quotes+about+life.+Prepare+to+be+filled+with+wisdom%2C+deeply+inspired%2C+and+thoroughly+motivated.&url=https%3A%2F%2Fselfsaid.30tools.com%2F38-very-short-quotes-about-life%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2F38-very-short-quotes-about-life%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2F38-very-short-quotes-about-life%2F)

[More](#)

2.17K Shares

Source: https://selfsaid.30tools.com/38-very-short-quotes-about-life/
