---
title: 120 Michael Jordan Quotes to Inspire Your Personal Best
date: '2023-12-21T14:12:16+01:00'
author: Seff Bray
description: >-
  Unleash your full potential with 120 Michael Jordan quotes that inspire
  greatness.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/michael-jordan-quotes.jpg'
original_url: 'https://selfsaid.30tools.com/michael-jordan-quotes/'
---

![120 Michael Jordan Quotes to Inspire Your Personal Best](https://seffsaid.com/wp-content/uploads/michael-jordan-quotes.jpg)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

Welcome to a powerful collection of 120 [inspirational sports quotes](https://selfsaid.30tools.com/inspirational-sports-quotes) from [Michael Jordan](https://www.forbes.com/profile/michael-jordan/), a collection that shines a light on the legacy of basketball’s iconic figure. These quotes go beyond the game, reflecting Jordan’s philosophy on life, success, and overcoming challenges. They offer insights into a [success mindset](https://selfsaid.30tools.com/mindsets-for-success) characterized by fierce competitiveness, hard work, and the drive to surpass obstacles.

For anyone seeking motivation—sports enthusiasts, athletes, or those in need of encouragement—Jordan’s words are a compelling reminder of the heights achievable with the right mindset and ethic. Let Michael Jordan’s spirit motivate you to soar to new achievements.

## 120 Michael Jordan Quotes

1.  “I’ve missed more than 9,000 shots in my career. I’ve lost almost 300 games. 26 times, I’ve been trusted to take the game-winning shot and missed. I’ve failed over and over and over again in my life. And that is why I succeed.” – Michael Jordan
2.  “Talent wins games, but teamwork and intelligence win championships.” – Michael Jordan
3.  “I can accept failure, everyone fails at something. But I can’t accept not trying.” – Michael Jordan
4.  “My attitude is that if you push me towards something that you think is a weakness, then I will turn that perceived weakness into a strength.” – Michael Jordan
5.  “To be successful you have to be selfish, or else you never achieve. And once you get to your highest level, then you have to be unselfish. Stay reachable. Stay in touch. Don’t isolate.” – Michael Jordan
6.  “Obstacles don’t have to stop you. If you run into a wall, don’t turn around and give up. Figure out how to climb it, go through it, or work around it.” – Michael Jordan
7.  “The key to success is failure.” – Michael Jordan
8.  “I play to win, whether during practice or a real game.” – Michael Jordan
9.  “You must expect great things of yourself before you can do them.” – Michael Jordan
10.  “If you quit once it becomes a habit. Never quit!” – Michael Jordan
11.  “Limits, like fear, are often just an illusion.” – Michael Jordan
12.  “Some people want it to happen, some wish it would happen, others make it happen.” – Michael Jordan
13.  “Always turn a negative situation into a positive situation.” – Michael Jordan
14.  “Heart is what separates the good from the great.” – Michael Jordan
15.  “My body could stand the crutches but my mind couldn’t stand the sideline.” – Michael Jordan
16.  “I never thought a role model should be negative.” – Michael Jordan
17.  “I realized that if I was going to achieve anything in life I had to be aggressive. I had to get out there and go for it.” – Michael Jordan
18.  “Just play. Have fun. Enjoy the game.” – Michael Jordan
19.  “The game is my wife. It demands loyalty and responsibility, and it gives me back fulfillment and peace.” – Michael Jordan
20.  “I’m not out there sweating for three hours every day just to find out what it feels like to sweat.” – Michael Jordan
21.  “Everybody has talent, but ability takes hard work.” – Michael Jordan
22.  “You have to expect things of yourself before you can do them.” – Michael Jordan
23.  “I can’t speak for the future. I have no crystal ball.” – Michael Jordan
24.  “The minute you get away from fundamentals – whether it’s proper technique, work ethic, or mental preparation – the bottom can fall out of your game, your schoolwork, your job, whatever you’re doing.” – Michael Jordan
25.  “There is no ‘i’ in team but there is in win.” – Michael Jordan
26.  “Even when I’m old and grey, I won’t be able to play it, but I’ll still love the game.” – Michael Jordan
27.  “If you do the work you get rewarded. There are no shortcuts in life.” – Michael Jordan
28.  I hope the millions of people I’ve touched have the optimism and desire to share their goals and hard work and perseverance with a [positive attitude.”](https://selfsaid.30tools.com/easy-ways-to-develop-a-positive-attitude) – Michael Jordan
29.  “Learning’s a gift, even when pain is your teacher.” – Michael Jordan
30.  “The best come from the worst.” – Michael Jordan
31.  “I’ve never been afraid to fail.” – Michael Jordan
32.  “I believe greatness is an evolutionary process that changes and evolves era to era.” – Michael Jordan
33.  “I never looked at the consequences of missing a big shot… when you think about the consequences you always think of a negative result.” – Michael Jordan
34.  “In reality, I never want to grow up.” – Michael Jordan
35.  “Once I made a decision, I never thought about it again.” – Michael Jordan
36.  “Winning isn’t always championships.” – Michael Jordan
37.  “I’ve never lost a game, I just ran out of time.” – Michael Jordan
38.  “Being Michael Jordan means acting the same as I always have.” – Michael Jordan
39.  I hope that my story, ‘Michael Jordan,’ can help, can influence, can motivate people to [overcome obstacles](https://selfsaid.30tools.com/proven-ways-to-overcome-obstacles), work hard, and follow their dreams.” – Michael Jordan
40.  “My heroes are and were my parents. I can’t see having anyone else as my heroes.” – Michael Jordan
41.  “When I will lose the sense of motivation and the sense to prove something as a basketball player, it’s time for me to move away from the game.” – Michael Jordan
42.  “My challenge when I came back was to face the young talent, to dissect their games, and show them maybe that they needed to learn more about the game than just the money aspect.” – Michael Jordan
43.  “I’ve always believed that if you put in the work, the results will come.” – Michael Jordan
44.  “I wasn’t really a work-conscious type of person. I was a player. I loved to play sports.” – Michael Jordan
45.  “I want to be the bridge to the next generation.” – Michael Jordan
46.  “I know fear is an obstacle for some people, but it’s an illusion to me.” – Michael Jordan
47.  “Failure is acceptable. but not trying is a whole different ballpark.” – Michael Jordan
48.  “Sometimes, things may not go your way, but the effort should be there every single night.” – Michael Jordan
49.  “Always work hard, never give up, and fight until the end because it’s not over until it’s over.” – Michael Jordan
50.  “I’m not a Twitterer, I’m not a twerker, I’m not a Facebooker, I’m not nothing. I’m old school.” – Michael Jordan
51.  “I play for the love of the game and that’s the reason I’m playing.” – Michael Jordan
52.  “Do I need my number retired throughout the course of the league to acknowledge what I’ve done? No.” – Michael Jordan
53.  “To learn to succeed, you must first learn to fail.” – Michael Jordan
54.  “You can practice shooting eight hours a day, but if your technique is wrong, then all you become is very good at shooting the wrong way.” – Michael Jordan
55.  “Enjoy every minute of life. Never second-guess life.” – Michael Jordan
56.  “I want to wake up every day and do whatever feels right. I want to enjoy life and not stress myself building my basketball legacy.” – Michael Jordan
57.  “I believe that a lot of people mistake my intensity for selfishness.” – Michael Jordan
58.  “I know the signs of scaredness.” – Michael Jordan
59.  “I’ve failed over and over and over again in my life. And that is why I succeed.” – Michael Jordan
60.  “The game has its ups and downs, but you can never lose focus of your individual goals and you can’t let yourself be beat because of lack of effort.” – Michael Jordan
61.  “The good part about being famous is being able to help people. The hard part is every day you can’t go out and be yourself.” – Michael Jordan
62.  “When you see me play, you see the results of all my hard work.” – Michael Jordan
63.  “My father used to say that it’s never too late to do anything you wanted to do. And he said, ‘You never know what you can accomplish until you try.'” – Michael Jordan
64.  “I’ve never been afraid to fail, but I have always been afraid of not trying.” – Michael Jordan
65.  “Sometimes you need to get hit in the head to realize that you’re in a fight.” – Michael Jordan
66.  “It’s heavy duty to try to do everything and please everybody. My job was to go out there and play the game of basketball as best I can.” – Michael Jordan
67.  “There’s no such thing as a perfect basketball player, and I don’t believe there is only one greatest player either.” – Michael Jordan
68.  “If everybody says it’s impossible, then I want to prove them wrong.” – Michael Jordan
69.  “You have competition every day because you set such high standards for yourself that you have to go out every day and live up to that.” – Michael Jordan
70.  “I want to be perceived as a guy who played his best in all facets, not just scoring. A guy who loved challenges.” – Michael Jordan
71.  “Every time I stepped on the basketball court, I believed I was the best player.” – Michael Jordan
72.  “It’s not about the shoes, it’s about what you do in them.” – Michael Jordan
73.  “I will not let anything get in the way of me and my competitive enthusiasm to win.” – Michael Jordan
74.  “I realize that I’m black, but I like to be viewed as a person, and that’s everybody’s wish.” – Michael Jordan
75.  “It doesn’t matter if you are a rookie or a veteran, you are going to be respected if you do things the right way.” – Michael Jordan
76.  “If you start to think you’re playing for money, or if you start to think you’re playing for fame, you lose sight of the reasons why you play.” – Michael Jordan
77.  “My challenge was to play the game and win, not to worry about what somebody thought I was.” – Michael Jordan
78.  “The best evaluation I can make of a player is to look in his eyes and see how scared they are.” – Michael Jordan
79.  “I think it’s the passion that I have for the game \[that drives me to do what I do\], the passion to improve, to constantly get better.” – Michael Jordan
80.  “My body is very precious to me. I’ve come to realize that without it, nothing else would matter.” – Michael Jordan
81.  “You can’t win unless you learn how to lose.” – Michael Jordan
82.  “I don’t count my sit-ups. I only start counting once it starts hurting.” – Michael Jordan
83.  “It’s a habit of mine now, noticing labels, logos, shoes.” – Michael Jordan
84.  “The game is my passion, my love, and it’s not just a job.” – Michael Jordan
85.  “I’ve always set short-term goals. As I look back, each one of the steps or successes led to the next one.” – Michael Jordan
86.  “I never thought about the odds at all. I just focused on playing basketball.” – Michael Jordan
87.  “I try to live my life like I play basketball.” – Michael Jordan
88.  “Basketball is my refuge, my sanctuary. I go back to being a kid on the playground.” – Michael Jordan
89.  “I trust my skills and the hard work I’ve put in, and that’s why I’m not afraid to take the last shot.” – Michael Jordan
90.  “You can’t be afraid to fail. It’s the only way you succeed – you’re not gonna succeed all the time, and I know that.” – Michael Jordan
91.  “I’m not a guy who is going to brag about myself. I’d rather let my game do all the talking.” – Michael Jordan
92.  “When you’re out there playing, you’re not thinking about the fame. You’re thinking about the competition.” – Michael Jordan
93.  “In any investment, you expect to have fun and make money.” – Michael Jordan
94.  “My heroes are those who risk their lives every day to protect our world and make it a better place—police, firefighters, and members of our armed forces.” – Michael Jordan
95.  “I remember when I was a kid and I would dream about this day, but I sure never dreamed it was going to be like this.” – Michael Jordan
96.  “I believe we all have a competitive nature within us, it’s just a matter of how we bring it out.” – Michael Jordan
97.  “It’s hard to say if the NBA is hurt by the influx of younger players, but it’s definitely impacted the league.” – Michael Jordan
98.  “Pressure is something you feel when you don’t know what you’re doing.” – Michael Jordan
99.  “The best player on the court works the hardest.” – Michael Jordan
100.  “You have to keep moving forward, no matter what the obstacles.” – Michael Jordan
101.  “Excellence is never a mistake. It is the result of high intention, sincere effort, and intelligent execution.” – Michael Jordan
102.  “A leader has to lead, or otherwise he has no business in leading.” – Michael Jordan
103.  “I don’t do things half-heartedly. Because I know if I do, then I can expect half-hearted results.” – Michael Jordan
104.  “The game of basketball has been everything to me. My place of refuge, place I’ve always gone where I needed comfort and peace.” – Michael Jordan
105.  “Every time I [feel tired](https://selfsaid.30tools.com/reasons-feel-tired) while exercising, I close my eyes to see that picture, to see that shot.” – Michael Jordan
106.  “Being able to concentrate and use your time well is everything.” – Michael Jordan
107.  “Success isn’t about the end result, it’s about what you learn along the way.” – Michael Jordan
108.  “Make it happen, no matter what.” – Michael Jordan
109.  “I don’t want to be the next anyone, I only want to be the best Michael Jordan.” – Michael Jordan
110.  “My challenge to myself is to play the game better each day and to try to improve myself, not against others but against myself.” – Michael Jordan
111.  “Commitment is a big part of what I am and what I believe.” – Michael Jordan
112.  “If you accept the expectations of others, especially negative ones, then you never will change the outcome.” – Michael Jordan
113.  “Life is a game, basketball is serious.” – Michael Jordan
114.  “The game always tells you where you stand.” – Michael Jordan
115.  “When the game is over, my job isn’t done.” – Michael Jordan
116.  “Greatness is a lot of small things done well every day.” – Michael Jordan
117.  “If you’re trying to achieve, there will be roadblocks. I’ve had them; everybody has had them. But obstacles don’t have to stop you.” – Michael Jordan
118.  “I’m not out there sweating for three hours every day just to find out what it feels like to sweat.” – Michael Jordan
119.  “You must be ready to fail miserably to achieve greatly.” – Michael Jordan
120.  “Champions do not become champions when they win the event, but in the hours, weeks, months and years they spend preparing for it.” – Michael Jordan

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fmichael-jordan-quotes%2F)

[Pin35](https://pinterest.com/pin/create/button/?url=/michael-jordan-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2Fmichael-jordan-quotes-PIN.jpg&description=Unleash+your+full+potential+with+120+Michael+Jordan+quotes+that+inspire+greatness.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=120+Michael+Jordan+Quotes+to+Inspire+Your+Personal+Best&url=https%3A%2F%2Fselfsaid.30tools.com%2Fmichael-jordan-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fmichael-jordan-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fmichael-jordan-quotes%2F)

[More](#)

35 Shares

Source: https://selfsaid.30tools.com/michael-jordan-quotes/
