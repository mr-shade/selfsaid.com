---
title: 48 Badass Quotes
date: '2024-07-04T12:39:02+02:00'
author: Seff Bray
description: >-
  A collection of badass quotes to help build a fearsome positive attitude and
  make you relentless in working towards your goals and dreams.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/badass-quotes.webp'
original_url: 'https://selfsaid.30tools.com/powerful-badass-quotes/'
---

![](https://seffsaid.com/wp-content/uploads/badass-quotes.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

Looking for the most powerful Badass Quotes of all time? Quotes that are so Badass that they will inspire and motivate you to succeed in life? These quotes will help you develop that go-getter badass mentality.

1.  “It is better to die on your feet than live on your knees.” – Emiliano Zapata  
    
2.  “Scar tissue is stronger than regular tissue. Realize the strength, move on.” – Henry Rollins  
    
3.  “You made me realize that everything comes with an expiry date.” – Anonymous  
    
4.  “Tough times never last, but tough people do.” – Dr. Robert Schuller  
    
5.  “You are the CEO of your life. Hire, fire, and promote accordingly.” – Anonymous  
    
6.  “I don’t need a weapon, I am one.” – Anonymous  
    
7.  “The fear of death follows from the fear of life. A man who lives fully is prepared to die at any time.” – [Mark Twain](https://selfsaid.30tools.com/25-inspirational-mark-twain-quotes)  
    
8.  “They laugh at me because I’m different. I laugh at them because they are the same.” – [Kurt Cobain](https://selfsaid.30tools.com/kurt-cobain-quotes)  
    
9.  “The goal is not to be rich, it is to be a legend.” – Anonymous  
    
10.  I got my own back.” – [Maya Angelou](https://selfsaid.30tools.com/maya-angelou-quotes)  
     
11.  “Be yourself, you’re not born to impress anyone.” – Anonymous  
     
12.  “When something bad happens, you have three choices. You can either let it define you, let it destroy you, or let it strengthen you.” – Dr. Seuss  
     
13.  “When people ask what I do, I say whatever it takes.” – Anonymous  
     
14.  “The question isn’t who is going to let me, it’s who is going to stop me.” – Ayn Rand  
     
15.  “Once I’m gone, I’m gone. I’ll never return into your life.” – Anonymous  
     
16.  “We are here to laugh at the odds and live our lives so well that Death will tremble to take us.” – Charles Bukowski  
     
17.  Everyone has a plan until they get punched in the mouth.” – [Mike Tyson](https://selfsaid.30tools.com/mike-tyson-quotes)  
     
18.  “You can quit talking to me if you don’t like my attitude.” – Anonymous  
     
19.  “Either I will find a way, or I will make one.” – Philip Sidney  
     
20.  “Path to success begins once you stop living the way society taught you. Live your own life. Create your own path to success. Never stop.” – Anonymous  
     
21.  “Kill them with success and bury them with a smile.” – Anonymous  
     
22.  “The world ain’t all sunshine and rainbows. It is a very mean and nasty place and it will beat you to your knees and keep you there permanently if you let it. You, me, or nobody is gonna hit as hard as life. But it ain’t how hard you hit; it’s about how hard you can get hit, and keep moving forward.” – Rocky Balboa  
     
23.  “If you aren’t going all the way, why go at all?” – Joe Namath  
     
24.  “I am thankful for all of those who said NO to me. Its because of them I’m doing it myself.” – Albert Einstein  
     
25.  “The best way out is always through.” – Robert Frost  
     
26.  If you don’t like the road you’re walking, start paving another one.” – [Dolly Parton](https://selfsaid.30tools.com/dolly-parton-quotes)  
     
27.  I’m not in this world to live up to your expectations and you’re not in this world to live up to mine.” – [Bruce Lee](https://selfsaid.30tools.com/bruce-lee-quotes)  
     
28.  “Today I will do what others won’t, so tomorrow I will do what others can’t.” – Jerry Rice  
     
29.  “It’s your place in the world; it’s your life. Go on and do all you can with it, and make it the life you want to live.” – Mae Jemison  
     
30.  “Listen, smile, agree, and then do whatever you were going to do anyway.” – Robert Downey Jr.  
     
31.  I’ve missed more than 9000 shots in my career. I’ve lost almost 300 games. 26 times I’ve been trusted to take the game winning shot and missed. I’ve failed over and over and over again in my life. And that is why I succeed.” – [Michael Jordan](https://selfsaid.30tools.com/michael-jordan-quotes)  
     
32.  “The best revenge is massive success.” – Frank Sinatra  
     
33.  “That which does not kill us makes us stronger.” – Friedrich Nietzsche  
     
34.  “What other people think about you has nothing to do with you and everything to do with them.” – Jen Sincero  
     
35.  “Champions keep playing until they get it right.” – Billie Jean King  
     
36.  The ones who are crazy enough to think they can change the world, are the ones that do.” – [Steve Jobs](https://selfsaid.30tools.com/steve-jobs-quotes)  
     
37.  “Don’t tell me the sky’s the limit when there are footprints on the moon.” – Paul Brandt  
     
38.  “Build your own dreams, or someone else will hire you to build theirs.” – Farrah Gray  
     
39.  “If your dreams don’t scare you, they are not big enough.” – Ellen Johnson Sirleaf  
     
40.  “Tell the negative committee that meets inside your head to sit down and shut up.” – Ann Bradford  
     
41.  “You create opportunities by performing, not complaining.” – Muriel Siebert  
     
42.  Don’t count the days, make the days count.” – [Muhammad Ali](https://selfsaid.30tools.com/muhammad-ali-quotes)  
     
43.  “Stop missing people who don’t even waste a second thinking about you.” – Anonymous  
     
44.  “I will go anywhere as long as it is forward.” – David Livingston  
     
45.  “Only those who are willing to risk going too far can possibly find out how far one can go.” – T.S Elliot  
     
46.  “Be original and let the world copy you.” – Anonymous  
     
47.  “Never apologize for who you are. It lets the whole world down.” – Jen Sincero  
     
48.  “It’s not the size of the dog in the fight, it’s the size of the fight in the dog.” – Mark Twain

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fpowerful-badass-quotes%2F)

[Pin6.29K](https://pinterest.com/pin/create/button/?url=/powerful-badass-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2Fbadass-quotes-PIN.jpg&description=A+collection+of+badass+quotes+to+help+build+a+fearsome+positive+attitude+and+make+you+relentless+in+working+towards+your+goals+and+dreams.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=48+Badass+Quotes&url=https%3A%2F%2Fselfsaid.30tools.com%2Fpowerful-badass-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fpowerful-badass-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fpowerful-badass-quotes%2F)

[More](#)

6.29K Shares

Source: https://selfsaid.30tools.com/powerful-badass-quotes/
