---
title: 50 Best Princess Diana Quotes
date: '2024-04-24T14:51:28+02:00'
author: Seff Bray
description: >-
  Discover the wisdom and warmth of Princess Diana by reading through this
  collection of 50 of her best quotes.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/Princess-Diana-Quotes.webp'
original_url: 'https://selfsaid.30tools.com/princess-diana-quotes/'
---

![Princess Diana](https://seffsaid.com/wp-content/uploads/Princess-Diana-Quotes.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

Here are 50 quotes attributed to Princess Diana that encapsulate her empathy, sense of humor, and dedication to humanitarian causes and reflect various aspects of her life, thoughts, and legacy

1.  “I don’t go by the rule book; I lead from the heart, not the head.” – Princess Diana
2.  “Everyone needs to be valued. Everyone has the potential to give something back.” – Princess Diana
3.  “Only do what your heart tells you.” – Princess Diana
4.  “Hugs can do great amounts of good, especially for children.” – Princess Diana
5.  “I wear my heart on my sleeve.” – Princess Diana
6.  Carry out a random [act of kindness](https://selfsaid.30tools.com/simple-acts-of-kindness-that-can-make-us-live-longer), with no expectation of reward, safe in the knowledge that one day someone might do the same for you.” – Princess Diana
7.  “The greatest problem in the world today is intolerance. Everyone is so intolerant of each other.” – Princess Diana
8.  “I’d like to be a queen in people’s hearts but I don’t see myself being queen of this country.” – Princess Diana
9.  “Family is the most important thing in the world.” – Princess Diana
10.  “I think the biggest disease the world suffers from in this day and age is the disease of people feeling unloved.” – Princess Diana
11.  “Being a princess isn’t all it’s cracked up to be.” – Princess Diana
12.  “I like to be a free spirit. Some don’t like that, but that’s the way I am.” – Princess Diana
13.  “I live for my sons. I would be lost without them.” – Princess Diana
14.  “If you find someone you love in your life, then hang on to that love.” – Princess Diana
15.  “I want my boys to have an understanding of people’s emotions, their insecurities, people’s distress, and their hopes and dreams.” – Princess Diana
16.  “Life is just a journey.” – Princess Diana
17.  “When you are happy you can forgive a great deal.” – Princess Diana
18.  “Anywhere I see suffering, that is where I want to be, doing what I can.” – Princess Diana
19.  “People think that at the end of the day a man is the only answer. Actually, a fulfilling job is better for me.” – Princess Diana
20.  “I touch people. I think everyone needs that. Placing a hand on a friend’s face means making contact.” – Princess Diana
21.  “I think the biggest disease this world suffers from is people feeling unloved.” – Princess Diana
22.  “The kindness and affection from the public have carried me through some of the most difficult periods, and always your love and affection have eased the journey.” – Princess Diana
23.  “They say it is better to be poor and happy than rich and miserable, but how about a compromise like moderately rich and just moody?” – Princess Diana
24.  “I knew what my job was; it was to go out and meet the people and love them.” – Princess Diana
25.  “I’m aware that people I have loved and have died and are in the spirit world looking after me.” – Princess Diana
26.  “Call me Diana, not Princess Diana.” – Princess Diana
27.  “Helping people in need is a good and essential part of my life, a kind of destiny.” – Princess Diana
28.  “I don’t want expensive gifts; I don’t want to be bought. I have everything I want. I just want someone to be there for me, to make me feel safe and secure.” – Princess Diana
29.  “Whatever ‘in love’ means, you can apply it to me.” – Princess Diana
30.  “Everyone of us needs to show how much we care for each other and, in the process, care for ourselves.” – Princess Diana
31.  “It’s vital that the monarchy keeps in touch with the people. It’s what I try and do.” – Princess Diana
32.  “The press is ferocious. It forgives nothing, it only hunts for mistakes.” – Princess Diana
33.  “I’m not a political figure. I am a humanitarian figure, always was, always will be.” – Princess Diana
34.  “You can’t comfort the afflicted with afflicting the comfortable.” – Princess Diana
35.  “I don’t even know how to use a parking meter, let alone a phone box.” – Princess Diana
36.  “People won’t need me forever and perhaps better people will replace me.” – Princess Diana
37.  “Two things stand like stone. Kindness in another’s trouble, courage in your own.” – Princess Diana
38.  “I am all about caring. I have always been like that.” – Princess Diana
39.  “I never know what my husband will do next… but I am always loyal to my husband.” – Princess Diana
40.  “If men had to have babies, they would only ever have one each.” – Princess Diana
41.  “I am not a political figure, nor do I want to be one, but I come with my heart.” – Princess Diana
42.  “It’s not sissy to show your feeling.” – Princess Diana
43.  “I wear my heart on my sleeve and my emotions are always on my skin.” – Princess Diana
44.  “It’s all about understanding, listening and caring for the people you’re involved with.” – Princess Diana
45.  “If there is a supreme being, he’s crazy.” – Princess Diana
46.  “There is no better way to dismantle a personality than to isolate it.” – Princess Diana
47.  “You have to give love to get love.” – Princess Diana
48.  “The world is too little aware of the waste of life, limb and land which military madness creates.” – Princess Diana
49.  “I don’t think many people will want me to be queen. Actually, when I say many people, I mean the establishment that I married into, because they have decided that I’m a non-starter.” – Princess Diana
50.  “The world is a better place when we remember to smile.” – Princess Diana

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fprincess-diana-quotes%2F)

[Pin4](https://pinterest.com/pin/create/button/?url=/princess-diana-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2FPrincess-Diana-Quotes-PIN.jpg&description=Discover+the+wisdom+and+warmth+of+Princess+Diana+by+reading+through+this+collection+of+50+of+her+best+quotes.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=50+Best+Princess+Diana+Quotes&url=https%3A%2F%2Fselfsaid.30tools.com%2Fprincess-diana-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fprincess-diana-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fprincess-diana-quotes%2F)

[More](#)

4 Shares

Source: https://selfsaid.30tools.com/princess-diana-quotes/
