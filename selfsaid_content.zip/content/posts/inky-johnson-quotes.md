---
title: 50 Inky Johnson Quotes To Motivate And Inspire You
date: '2024-07-08T13:08:01+02:00'
author: Seff Bray
description: >-
  Explore 50 Inky Johnson quotes: powerful lessons on resilience, hard work, and
  personal growth from a motivational icon. Get inspired!
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/Inky-Johnson-quotes.webp'
original_url: 'https://selfsaid.30tools.com/inky-johnson-quotes/'
---

![](https://seffsaid.com/wp-content/uploads/Inky-Johnson-quotes.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

[Inky Johnson](https://www.inkyjohnson.com/)‘s life story is a remarkable tale of triumph over tragedy. A promising collegiate athlete, Johnson’s burgeoning football career was abruptly halted by a devastating injury during a game. This life-altering event, however, did not quell his spirit. Instead, it became the catalyst for his transformation into a motivational speaker, touching the hearts of millions worldwide.

His powerful messages often resonate deeply with those facing their own battles. Johnson’s ability to convert personal adversity into universal [lessons of perseverance](https://selfsaid.30tools.com/quotes-about-perseverance) and [strength](https://selfsaid.30tools.com/quotes-about-strength) is evident in his impactful oratory. His words have become synonymous with courage, determination, and the relentless pursuit of excellence against all odds.

## The 50 Best Inky Johnson Quotes

1.  “Play the hand you’re dealt like it’s the one you’ve always wanted.”​​ – Inky Johnson
2.  “Watch your thoughts, they become your words. Watch your words, they become your actions. Watch your actions, they produce your future.”​​ – Inky Johnson
3.  “Impose your will on life and life will have no choice but to give you what you want.”​​ – Inky Johnson
4.  “It’s not where you’re trying to go in life that’s the problem. It’s what you are willing to leave behind in order to get there.”​​ – Inky Johnson
5.  “Be stronger than your strongest excuse!”​​ – Inky Johnson
6.  “See something. Believe in it, and go get it..”​​ – Inky Johnson
7.  “Allow the opposition to make you better.”​​ – Inky Johnson
8.  “Try to be better than the person you were yesterday.”​​ – Inky Johnson
9.  “Ease is a greater threat to progress than hardship.”​​ – Inky Johnson
10.  “Perspective drives performance every day of the week.”​​ – Inky Johnson
11.  “Commitment is staying true to what you said you would do long after the mood that you said it in has left.”​​ – Inky Johnson
12.  “Impose your will on life and life will have no choice but to give you what you want.”​​ – Inky Johnson
13.  “People get upset not because of the adversity they face, but because their adversity reveals who they really are.”​​ – Inky Johnson
14.  Every [positive change](https://selfsaid.30tools.com/100-positive-affirmations-that-will-change-your-life), every jump to a higher level involves a rite of passage. Each time to ascend to a higher rung on the ladder of growth, we must go through a period of discomfort, or adversity.”​​ – Inky Johnson
15.  “After we come out of the storm we shouldn’t be the same individual that walked into it… That’s what the storms, opposition & adversity is about.”​​ – Inky Johnson
16.  “Eventually you’ll end up where you need to be, surrounded with who you’re meant to be with and Impact who you’re meant to Inspire.”​​ – Inky Johnson
17.  “No amount of money ever bought a second of time… Don’t get so busy making a living that you forget to make a life!”​​ – Inky Johnson
18.  “Peace is the result of retraining your mind to process life as it is, rather than as you think it should be.”​​ – Inky Johnson
19.  “More of us would learn from our mistakes if we weren’t so busy denying them.”​​ – Inky Johnson
20.  “Stop worrying how it’s going to happen and start trusting that it will.”​​ – Inky Johnson
21.  “Most have the will to win, few have the will to prepare to win.”​​ – Inky Johnson
22.  “Don’t be upset by the results you didn’t get with the work you didn’t do.”​​ – Inky Johnson
23.  “The process is more important than the product.”​​ – Inky Johnson
24.  “Control what you can control today!”​​ – Inky Johnson
25.  “Never let a situation or circumstance define your life, no matter what it may be.”​​ – Inky Johnson
26.  “We have to learn to be comfortable being uncomfortable: Pull the strip off and activate your greatness!”​​ – Inky Johnson
27.  “When we hold onto our history, we do it at the expense of our destiny… At some point you just have to let go of what you thought should have happened and live in what’s happening.”​​ – Inky Johnson
28.  “Why come into an environment and complain about being in the environment and still do the work!”​​ – Inky Johnson
29.  “Can we be committed to the process of what we’re doing without being emotionally attached to the results of what we’re doing.”​​ – Inky Johnson
30.  “We don’t burnout because of what we do, we burnout because life makes us forget why we do it.”​​ – Inky Johnson
31.  “Just work!!! Don’t be driven by the outcome. Embrace the PROCESS!”​​ – Inky Johnson
32.  “Never allow life to make you forget why you started!”​​ – Inky Johnson
33.  “Courage is the commitment to being without any guarantee of success.”​​ – Inky Johnson
34.  “At a certain point, the old you has to die off for the new you to become.”​​ – Inky Johnson
35.  “Pride is concerned with who is right. Humility is concerned with what is right.”​​ – Inky Johnson
36.  “Most have the will to win, few have the will to PREPARE to win.”​​ – Inky Johnson
37.  “We have to learn to be comfortable being uncomfortable. Pull the strip off and activate your greatness!”​​ – Inky Johnson
38.  “Stop worrying how it’s going to happen and start trusting that it will.”​​ – Inky Johnson
39.  “Character is not something we inherit. Character is something we have to wake up and build.”​​ – Inky Johnson
40.  “Peace is the result of retraining your mind to process life as it is, rather than as you think it should be.”​​ – Inky Johnson
41.  “Character supersedes talent. Don’t allow your talent to take you where your character can’t sustain you.”​​ – Inky Johnson
42.  “Sometimes we’re tested not to show our weaknesses but to discover our strengths!”​​ – Inky Johnson
43.  “Be careful not to try and fast forward yourself into a future you haven’t earned. Blessings on the journey.”​​ – Inky Johnson
44.  “We never know what life is protecting us from. Control what you can control today.”​​ – Inky Johnson
45.  “People don’t burn out because of what they do. People burn out because life makes them forget why they do it.”​​ – Inky Johnson
46.  “Every next level of your life will demand a different version of you.”​​ – Inky Johnson
47.  “It’s not where you’re trying to go in life that is the problem. It’s what are you willing to leave behind in order to get there.”​​ – Inky Johnson
48.  “The most important project you can work on is molding yourself into the person you want to become.”​​ – Inky Johnson
49.  “If you can’t handle someone at their worst then you don’t deserve them when they are at their best.”​​ – Inky Johnson
50.  “No amount of money ever bought a second of time. Don’t get so busy making a living that you forget to make a life!”​​ – Inky Johnson

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Finky-johnson-quotes%2F)

[Pin9](https://pinterest.com/pin/create/button/?url=/inky-johnson-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2FInky-Johnson-Quotes-PIN2.jpg&description=Explore+50+Inky+Johnson+quotes%3A+powerful+lessons+on+resilience%2C+hard+work%2C+and+personal+growth+from+a+motivational+icon.+Get+inspired%21+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=50+Inky+Johnson+Quotes+To+Motivate+And+Inspire+You&url=https%3A%2F%2Fselfsaid.30tools.com%2Finky-johnson-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Finky-johnson-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Finky-johnson-quotes%2F)

[More](#)

9 Shares

Source: https://selfsaid.30tools.com/inky-johnson-quotes/
