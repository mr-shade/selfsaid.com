---
title: 160 Thinking of You Quotes for the Love of Your Life
date: '2023-12-23T17:48:48+01:00'
author: Seff Bray
description: >-
  Dive into our collection of 160 Thinking Of You Quotes and discover the
  perfect way to express your deepest emotions to someone special.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/Thinking-Of-You-Quotes.jpg'
original_url: 'https://selfsaid.30tools.com/thinking-of-you-quotes/'
---

![Thinking Of You Quotes](https://seffsaid.com/wp-content/uploads/Thinking-Of-You-Quotes.jpg)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

“Thinking of you” quotes have a special way of expressing a wide range of emotions that touch our hearts. Whether for him or for her, these quotes beautifully capture feelings of fondness, warmth, affection, and the joy that comes with thoughts of a loved one.

They inspire you to [follow your heart](https://selfsaid.30tools.com/follow-your-heart-quotes), no matter the distance. These messages act as [affirmations](https://selfsaid.30tools.com/50-powerful-affirmations-that-can-change-life) of care and adoration, bridging the miles to connect with those we hold dear. They are more than just words; they create emotional connections with the people we love the most.

*   “I think about you constantly, whether it’s with my mind or my heart.” – Terri Guillemets
*   “Thinking of you is easy – I do it every day. Missing you is the heartache, that never goes away.” – Michael Pryce
*   “I think of you with every waking moment of my life and dream of you with every dream that I have; I miss you.” – Kong Moua
*   “You’re everywhere except right here and it hurts.” – Rupi Kaur
*   “I just hugged you in my thoughts… hope you felt the squeeze!” – Unknown
*   “You may be out of my sight… but never out of my mind… Thinking of You!” – Unknown
*   “You’re in my thoughts and in my heart wherever I may go; On Valentine’s Day, I’d like to say I care more than you know.” – Unknown
*   “Thinking of you keeps me awake. Dreaming of you keeps me asleep. Being with you keeps me alive.” – Unknown
*   “Thinking of you is one of my favorite things to do. Just saying.” – Unknown
*   “Whenever you are in my mind, I [never feel bored](https://selfsaid.30tools.com/7-ways-to-make-your-life-exciting-again), I never feel lonely, I never feel gloomy. Just having you in my thoughts is enough to keep me satisfied.” – Unknown
*   “Although we are miles apart, the thought and touch of you lives within my heart. It is for that reason my dear you will always feel near, even though we are thousands of miles apart!” – Andrew Guzaldo
*   “Somewhere someone is thinking of you. Someone is calling you an angel. This person is using celestial colors to paint your image. Someone is making you into a vision so beautiful that it can only live in the mind.” – Henry Rollins
*   “I think of you, and I dream of you all of the time. What am I going to do? I want my heart to tell you that I am in love with you.” – Unknown
*   “Just wanted to let you know… You’re in my thoughts… all the time!” – Unknown
*   “Thinking of you, and counting the days until we meet again.” – Unknown
*   I think about you when I wake up and then again before I [fall asleep](https://selfsaid.30tools.com/how-to-fall-asleep-fast). You see, you’re never out of my thoughts.” – Unknown
*   “My thoughts are free to go anywhere, but it’s surprising how often they head in your direction.” – Perez
*   “You’re such a hard habit to break. I’ve been thinking about you lately and I’ve got you on my mind.” – Chicago
*   “I find myself smiling whenever I think of you. Note: I smile a lot.” – Unknown
*   “You’re in my thoughts, in my heart, and every breath I take.” – Unknown
*   “Loving you is not the best part of my life. It is every part of my life.” – Unknown
*   “Every time you look at me and see me smiling, just know that I am thinking of you.” – Unknown
*   “You probably deserve someone better but I swear no one wants to wakes up to your face as much as I do.” – Unknown
*   “Thinking of you is easy; I do it every day. Missing you is the heartache, that never goes away.” – Michael Pryce
*   “My thoughts are free to go anywhere, but it’s surprising how often they head in your direction.” – Unknown
*   “I find your image in everything: sunshine, wind, waves… I’m just thinking of you!” – Unknown
*   “Not only have you touched my mind so I only think of you; but you’ve touched my heart in a way that I will never forget you.” – Unknown
*   “If every time I thought of you, a star fell, well, the sky would be empty.” – Unknown
*   “I think about you constantly, whether it’s with my mind or my heart.” – Albany Bach Reid
*   “My heart dances with joy when I think about you.” – Debasish Mridha
*   “I saw two fallen branches in the shape of a heart. Thought of you.” – Stephanie Perkins
*   “When I count my blessings, I count you twice.” – Unknown
*   “Every now and then my heart wanders back in time and all those old feelings awaken the memories in my mind.” – Fad Ibra
*   I still find each day too short for all the thoughts I want to think, all the walks I want to take, all the [books I want to read](https://selfsaid.30tools.com/8-benefits-of-reading-books), and all the friends I want to see.” – John Burroughs
*   “Your thought has taken over my body and my life, every second of every day I think of you.” – Unknown
*   “You may be far away, but you are never far from my heart. Thinking of you!” – Unknown
*   “I am thinking of you, in my sleepless solitude tonight. If it’s wrong to love you, then my heart just won’t let me be right.” – Mariah Carey
*   “When I think of you, the smile is on my face, my arms need yours, my eyes need yours and my body needs yours.” – Unknown
*   “Every time I think of you, it is like getting a hug from the inside out.” – Unknown
*   “You may be out of sight, but you are never out of my mind.” – Unknown
*   “Just a note to say I’m thinking of you, and I hope that you’re doing well.” – Unknown
*   “Thinking of you as I realize that you are the one that holds the key to my heart.” – Unknown
*   “Thinking of you is one of the things that brightens my day.” – Unknown
*   “When I think of you, I think of the happiness that you bring to my life.” – Unknown
*   “When you’re on my mind, I feel filled with joy and hope.” – Unknown
*   “Your thought brings light to my face and joy to my heart.” – Unknown
*   “Thinking of you, and hoping your heart feels the love.” – Unknown
*   “You are the sun in my day, the wind in my sky, the waves in my ocean, and the beat in my heart… Thinking of you!” – Paul
*   “I am thinking about you. Please be my reality who is better than a dream, be a thought who will ever be in my head.” – Unknown
*   “When I think about you, I am reminded of the reasons why I love you.” – Unknown
*   “My thoughts are filled with you, my dreams are built around you.” – Unknown
*   “Thinking of you is one of my favorite things to do.” – Unknown
*   “I smile to the sky when I think of you.” – Unknown
*   “Thinking of you warms my heart.” – Unknown
*   “When I think of you, I think of the great times we’ve had and the wonderful times yet to come.” – Unknown
*   “Thinking of you is a poison I drink often.” – Atticus
*   “Thinking of you, loving you, and hoping you know if you need anything, I’m always here for you.” – Unknown
*   “I think of you with every waking moment of my life and dream of you with every dream that I have.” – Unknown
*   “When I think of you, my heart overflows with joy and pleasure.” – Unknown
*   “Every time my phone buzzes, I hope it’s you missing me.” – Unknown
*   “Your voice is my favorite sound, and your name is my favorite noun.” – Unknown
*   “When I think of you, I think of great things.” – Unknown
*   “Distance means so little when someone means so much.” – Tom McNeal
*   “In case you ever foolishly forget: I am never not thinking of you.” – Virginia Woolf
*   “I think about you constantly, whether it’s with my mind or my heart.” – Terri Guillemets
*   “Thinking of you. Today. Tomorrow. Always.” – Unknown
*   “I smile like an idiot when I think about you.” – Unknown
*   “Whenever I miss you, I look at my heart. Because it’s the only place I can find you.” – Unknown
*   “You’re in my thoughts and prayers.” – Unknown
*   “Just thinking of you today makes my heart feel happy.” – Unknown
*   “You are the sun in my day, the wind in my sky, the waves in my ocean, and the beat in my heart.” – Unknown
*   “I think of you and a smiling face I always visualize, wishing you is a happy process.” – Unknown
*   “If I had a single flower for every time I think about you, I could walk forever in my garden.” – Claudia Adrienne Grandi
*   “Thinking of you is easy – I do it every day. Missing you is the heartache, that never goes away.” – Michael Pryce
*   “A day without you is like a day without sunshine… Thinking of you.” – Unknown
*   “I just hugged you in my thoughts. Hope you felt the squeeze.” – Unknown
*   “When I think of you, I think of kindness, wisdom, and love. Thanks for being you.” – Sam Crow
*   “Late at night when all the world is sleeping, I stay up and think of you.” – Selena Quintanilla Perez
*   “The one good thing about not seeing you is that I can write you letters.” – Svetlana Alliluyeva
*   “If it’s the thought that counts, then I’ll be counting a lot today.” – Unknown
*   “I think about you now and then about all the mornings that could have been.” – Atticus
*   “Thinking of you is a pleasant phrase for me. It means you’re not far away but just a thought away.” – Unknown
*   “When I want to smile, I know exactly what to do, I just close my eyes and I think of you.” – Unknown
*   “Thinking of you in time of need must mean you’re the one thing they need.” – Unknown
*   “Every moment spent with you is a moment I treasure, and when you’re not here, I treasure the memories.” – Unknown
*   “I carry your heart with me (I carry it in my heart).” – E.E. Cummings
*   “The thought of you brings a smile to my face and peace to my heart.” – Unknown
*   “Thinking of you is like a breath of fresh air.” – Unknown
*   “You’re always the first and the last thing on this heart of mine. No matter where I go, or what I do, I’m thinking of you.” – Dierks Bentley
*   “When I think of you, my heart soars high; when I miss you, I ache with longing.” – Unknown
*   “You’re in my thoughts, in my dreams, and every place in between.” – Unknown
*   “Just a note to say… you’re on my mind and in my heart.” – Unknown
*   “Thinking of you is like remembering I have my favorite ice cream in the freezer.” – Unknown
*   “I close my eyes and see you there. But when I open them and see nothing there, I realize how much I miss you.” – Unknown
*   “Every time you cross my mind, I break out in exclamations of thanks to God.” – Unknown
*   “Your thought is a melody to my soul, reminding me of the beauty of life.” – Unknown
*   “Thinking of you feels like home.” – Unknown
*   “When I think of you, the world’s alright with me.” – Bill Withers
*   “To think of you is to smile.” – Unknown
*   “I don’t know where you start and I end, because when I think of you, it’s like I see a part of myself.” – Unknown
*   “Even though we are miles apart, you are still a very important part of who I am.” – Unknown
*   “The thought of you makes my days brighter and my nights filled with dreams.” – Unknown
*   “I think of you in the silence of the night and find your presence a comfort.” – Unknown
*   “Thinking of you is the highlight of my day.” – Unknown
*   “You may be out of my sight, but you are never out of my thoughts.” – Unknown
*   “When I think of you, I think of all the good times we’ve spent together.” – Unknown
*   “Thinking of you is like a warm cup of coffee in a cold morning.” – Unknown
*   “I think of you and a smile springs to my lips, a light to my eyes.” – Unknown
*   “You are the one I think of when the room is silent.” – Unknown
*   “Whenever I miss you, I just look at my heart. Because that’s where I’ll find you.” – Unknown
*   “Thinking of you is the easiest and nicest thing I do all day.” – Unknown
*   “You’re the first thought in my head in the morning and the last thought before I fall asleep.” – Unknown
*   “I think of you in the colors that fill my eyes in the morning and the last ones to fade at night.” – Unknown
*   “You are the one I always think of. You are the one that completes me.” – Unknown
*   “Even in the busiest of days, I never forget to think of you.” – Unknown
*   “Every time my phone vibrates, I hope you’re the reason for it.” – Unknown
*   “I find myself smiling whenever I think of you.” – Unknown
*   “Your thought is a treasure I carry everywhere.” – Unknown
*   “Every song I hear reminds me of how much I miss you and think of you.” – Unknown
*   “I think of you, and a feeling of peace comes over me.” – Unknown
*   “You may be far in distance, but not in my thoughts.” – Unknown
*   “Thinking of you adds a wonderful touch of love to my day.” – Unknown
*   “Whenever I struggle to smile, I just close my eyes and think of you.” – Unknown
*   “The thought of you brightens my day like the sun.” – Unknown
*   “Thinking of you feels like a warm blanket on a chilly morning.” – Unknown
*   “You’re my favorite daydream.” – Unknown
*   “I think of you, and I’m filled with gratitude for having you in my life.” – Unknown
*   “Every thought of you warms my heart like a sunny day.” – Unknown
*   “Just a thought of you brings a smile to my face.” – Unknown
*   “You might be out of sight but never out of mind.” – Unknown
*   “Every time I think of you, I get the sweetest feeling.” – Unknown
*   “Thinking of you is a little escape from the reality of my everyday life.” – Unknown
*   “You are always in my thoughts, and just knowing you’re there brings peace to my heart.” – Unknown
*   “I’m sending a little message your way to remind you I’m thinking of you today.” – Unknown
*   “Just thinking of you brings a smile to my face. A big, big smile.” – Unknown
*   “Whenever I find myself thinking of you, I also remember how fortunate I am to have you in my life.” – Unknown
*   “Something about you is so addictive.” – Unknown
*   “Every time I think of you, I smile.” – Unknown
*   “You’re my favorite thought.” – Unknown
*   “Just dropping by in your thoughts to say hello!” – Unknown
*   “When I think of you, my soul lights up.” – Unknown
*   “You’re in my thoughts and in my heart.” – Unknown
*   “Thinking of you is a beautiful thing.” – Unknown
*   “You occupy my mind every minute of every day.” – Unknown
*   “You’re like a song stuck in my head, and I’m loving every lyric.” – Unknown
*   “When you’re on my mind, I feel at peace.” – Unknown
*   “You’re not just in my thoughts. You’re in my heart.” – Unknown
*   “I catch myself smiling whenever I think of you.” – Unknown
*   “Thinking of you is my favorite part of the day.” – Unknown
*   “You’re the reason I look down at my phone and smile.” – Unknown
*   “Just wanted to let you know I’m thinking of you.” – Unknown
*   “Thinking of you feels like a warm hug to my heart.” – Unknown
*   “You’re in my thoughts more than you know.” – Unknown
*   “I find peace when I think of you.” – Unknown
*   “You’ve been on my mind today, and it’s only 8 AM.” – Unknown
*   “You’re like a cozy sweater on a chilly morning. Thinking of you warms me.” – Unknown
*   “Every little thought of you turns into a big smile for me.” – Unknown
*   “I think of you, and the world seems right again.” – Unknown
*   “My heart whispers your name when I’m thinking of you.” – Unknown

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fthinking-of-you-quotes%2F)

[Pin2](https://pinterest.com/pin/create/button/?url=/thinking-of-you-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2FThinking-Of-You-Quotes-PIN.jpg&description=Dive+into+our+collection+of+160+Thinking+Of+You+Quotes+and+discover+the+perfect+way+to+express+your+deepest+emotions+to+someone+special.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=160+Thinking+of+You+Quotes+for+the+Love+of+Your+Life&url=https%3A%2F%2Fselfsaid.30tools.com%2Fthinking-of-you-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fthinking-of-you-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fthinking-of-you-quotes%2F)

[More](#)

2 Shares

Source: https://selfsaid.30tools.com/thinking-of-you-quotes/
