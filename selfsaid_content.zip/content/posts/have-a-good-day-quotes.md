---
title: 218 Inspirational ‘Have A Good Day’ Quotes to Uplift and Inspire
date: '2024-09-13T16:04:17+02:00'
author: Seff Bray
description: >-
  Allow these 218 inspirational 'Have A Good Day' Quotes to serve as a reminder
  of life's beauty & potential, filling your day with positivity.
tags: []
featured_image: >-
  https://seffsaid.com/wp-content/uploads/Inspirational-Have-A-Good-Day-Quotes.jpg
original_url: 'https://selfsaid.30tools.com/have-a-good-day-quotes/'
---

![218 Inspirational 'Have A Good Day' Quotes](https://seffsaid.com/wp-content/uploads/Inspirational-Have-A-Good-Day-Quotes.jpg)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

Starting your day on a positive note can make all the difference in how things unfold. These 218 uplifting “Have A Good Day” quotes are here to brighten your mood and help spread some positivity.

## Have A Good Day Quotes

1.  “Every day is a good day to be alive, whether the sun’s shining or not.” – Marty Robbins
2.  “A day is a day. It’s just a measurement of time. Whether it’s a good day or a bad day is up to you. It’s all a matter of perception.” – Donald L. Hicks
3.  “On a good day, when you have a clear plan, you are able to execute whatever you wanted.” – Jasprit Bumrah
4.  “Every day is a good day. There is something to learn, care and celebrate.” – Amit Ray
5.  “Any day above ground is a good day. Before you complain about anything, be thankful for your life and the things that are still going well.” – Germany Kent
6.  “It’s a great day to be alive. I know the sun’s still shining when I close my eyes.” – Travis Tritt
7.  “Today’s a great day to change a life. Starting with yours.” – Robin Sharma
8.  “Every single day is a good day no matter how bright or dark it is, because it always brings an opportunity to start a positive beginning in your life.” – Edmond Mbiaka
9.  “Every day is a new beginning. Take a deep breath, smile, and start again.” – Unknown
10.  “A good day is a good day. A bad day is a good story.” – Glennon Doyle Melton
11.  I wake up [every morning](https://selfsaid.30tools.com/sticky-notes-we-need-to-read-every-morning) believing today is going to be better than yesterday.” – Will Smith
12.  “Every day may not be good, but there’s something good in every day.” – Alice Morse Earle
13.  A good day is one where I can not just [read a book](https://selfsaid.30tools.com/8-benefits-of-reading-books), but write a review of it.” – Christopher Hitchens
14.  “This is a wonderful day. I’ve never seen this one before.” – [Maya Angelou](https://selfsaid.30tools.com/maya-angelou-quotes)
15.  “If you don’t think every day is a good day, just try missing one.” – Cavett Robert
16.  “Today’s a good day to have a good day.” – Unknown
17.  “I hope everyone that is reading this is having a really good day.” – Unknown
18.  “Rise up, start fresh, see the bright opportunity in each day.” – Unknown
19.  “Be in love with your life. Every minute of it.” – Jack Kerouac
20.  “Every day is a good day, some are just a little better than others.” – Jeff Garthwaite
21.  “You get lessons from the worst days, and memories from the best days. Today will be a good day.” – Unknown
22.  Every day is another chance to [change your life.”](https://selfsaid.30tools.com/5-simple-daily-habits-that-can-actually-change-your-life) – Unknown
23.  “Write it on your heart that every day is the best day in the year.” – Ralph Waldo Emerson
24.  “Every day is a chance to begin again. Don’t focus on the failures of yesterday, start today with positive thoughts and expectations.” – Catherine Pulsifer
25.  “Today is a good day to try.” – Quasimodo, The Hunchback of Notre Dame
26.  “Each day is a little life: every waking and rising a little birth, every fresh morning a little youth, every going to rest and sleep a little death.” – Arthur Schopenhauer
27.  “I have always been delighted at the prospect of a new day, a fresh try, one more start, with perhaps a bit of magic waiting somewhere behind the morning.” – J. B. Priestley
28.  “A well-spent day brings happy sleep.” – Leonardo da Vinci
29.  “Today is your day. Your mountain is waiting. So… get on your way.” – Dr. Seuss
30.  Don’t count the days, make the days count.” – [Muhammad Ali](https://selfsaid.30tools.com/muhammad-ali-quotes)
31.  “The only difference between a good day and a bad day is your attitude.” – Dennis S. Brown
32.  “Keep your face always toward the sunshine—and shadows will fall behind you.” – Walt Whitman
33.  “You are never too old to set another goal or to dream a new dream.” – C.S. Lewis
34.  “Happiness often sneaks in through a door you didn’t know you left open.” – John Barrymore
35.  “It’s a new day. Yesterday’s failure is redeemed at the sunrise.” – Todd Stocker
36.  “Success is to wake up each morning and consciously decide that today will be the best day of your life.” – Ken Poirot
37.  Give every day the chance to become the most beautiful day of your life.” – [Mark Twain](https://selfsaid.30tools.com/25-inspirational-mark-twain-quotes)
38.  “The sun is a daily reminder that we too can rise again from the darkness, that we too can shine our own light.” – S. Ajna
39.  “This is not just another day, this is yet another chance to make your dreams come true.” – Unknown
40.  “Rise up and attack the day with enthusiasm.” – Unknown
41.  “Each new day is a blank page in the diary of your life. The secret of success is in turning that diary into the best story you possibly can.” – Douglas Pagels
42.  “The difference between a good day and a bad day is your attitude.” – Dennis S. Brown
43.  “Don’t wake up with the regret of what you couldn’t accomplish yesterday. Wake up while thinking about what you will be able to achieve today.” – Unknown
44.  “Some days you just have to create your own sunshine.” – Sam Sundquist
45.  [“Life is too short](https://selfsaid.30tools.com/the-26-best-short-life-quotes) to start your day with broken pieces of yesterday. It will definitely destroy your wonderful today and ruin your great tomorrow.” – Unknown
46.  “Every new morning gives you an opportunity to make someone’s day better.” – Unknown
47.  “Smile in the mirror. Do that every morning and you’ll start to see a big difference in your life.” – Yoko Ono
48.  “Morning not only forgives, it forgets.” – Marty Rubin
49.  “Every morning brings new potential, but if you dwell on the misfortunes of the day before, you tend to overlook tremendous opportunities.” – Harvey Mackay
50.  “To change the world, one has to ignore its persistent illusion of permanence.” – Thích Nhất Hạnh
51.  “The best way to start the day is with a cup of positivity.” – Asha Tyson
52.  “Your future is created by what you do today, not tomorrow.” – Robert Kiyosaki
53.  “Every day is a new beginning. Treat it that way. Stay away from what might have been, and look at what can be.” – Marsha Petrie Sue
54.  “Each good morning we are born again, what we do today is what matters most.” – Buddha
55.  “You’ve never lived this day before, and you never will again. Make the most of it!” – Unknown
56.  “Mornings are a new beginning in every man’s life. One should be thankful for every morning that he can stand up.” – Lailah Gifty Akita
57.  “Every day brings new choices.” – Martha Beck
58.  “Joyful morning, good morning, good day.” – Lailah Gifty Akita
59.  “Every morning is a beautiful morning.” – Terri Guillemets
60.  “Don’t let yesterday use up too much of today.” – Will Rogers
61.  “Morning is an important time of day, because how you spend your morning can often tell you what kind of day you are going to have.” – Lemony Snicket
62.  “When you do something noble and beautiful and nobody noticed, do not be sad. For the sun every morning is a beautiful spectacle and yet most of the audience still sleeps.” – [John Lennon](https://selfsaid.30tools.com/john-lennon-quotes)
63.  “Every day is different, and some days are better than others, but no matter how challenging the day, I get up and live it.” – Muhammad Ali
64.  “If you get up in the morning and think the future is going to be better, it is a bright day. Otherwise, it’s not.” – [Elon Musk](https://selfsaid.30tools.com/elon-musk-quotes)
65.  “With the new day comes new strength and new thoughts.” – Eleanor Roosevelt
66.  “I remind myself every morning: Nothing I say this day will teach me anything. So if I’m going to learn, I must do it by listening.” – Larry King
67.  “Every day is a new day, and you’ll never be able to find happiness if you don’t move on.” – Carrie Underwood
68.  “There was never a night or a problem that could defeat sunrise or hope.” – Bernard Williams
69.  “Every morning, I wake up saying, I’m still alive, a miracle. And so I keep on pushing.” – Jim Carrey
70.  “I like my coffee black and my mornings bright.” – Terri Guillemets
71.  “Each morning we are born again. What we do today is what matters most.” – Buddha
72.  “When I wake up every morning, I thank God for the new day.” – F. Sionil Jose
73.  “The sun is new each day.” – Heraclitus
74.  “I arise in the morning torn between a desire to improve the world and a desire to enjoy the world.” – E.B. White
75.  “Every morning is a chance at a new day.” – Marjorie Pay Hinckley
76.  “Today’s goals: Coffee and kindness. Maybe two coffees, and then kindness.” – Nanea Hoffman
77.  “An early-morning walk is a blessing for the whole day.” – Henry David Thoreau
78.  “I wake up laughing. Yes, I wake up in the morning and there I am just laughing my head off.” – Bruce Willis
79.  “Every day I feel is a blessing from God. And I consider it a new beginning. Yeah, everything is beautiful.” – Prince
80.  “Every day is a chance to be better than the day before.” – Unknown
81.  A good day starts with a [positive attitude](https://selfsaid.30tools.com/easy-ways-to-develop-a-positive-attitude) and a great cup of coffee.” – Unknown
82.  “Wake up and be awesome!” – Unknown
83.  “Today is a good day for a good day.” – Unknown
84.  “Be the sunshine in someone’s life today.” – Unknown
85.  “Every day is another opportunity to change and improve yourself. Take it and make the most of it.” – Unknown
86.  “Leave yesterday’s worries behind and focus on the brightness of today.” – Unknown
87.  “A new day means a new life, new hope. Be positive and enjoy your day.” – Unknown
88.  “Make today so awesome that yesterday gets jealous.” – Unknown
89.  “The best preparation for tomorrow is doing your best today.” – H. Jackson Brown Jr.
90.  “Every day is a chance to change your life.” – Unknown
91.  “Let today be the day you give up who you’ve been for who you can become.” – Hal Elrod
92.  “Today is your day to paint life in bold colors.” – Kobi Yamada
93.  “Every day is a new opportunity to live your best story.” – Oprah Winfrey
94.  “Turn your face to the sun and the shadows fall behind you.” – Maori Proverb
95.  “You don’t have to be great to start, but you have to start to be great.” – Zig Ziglar
96.  Success is not final, failure is not fatal: It is the courage to continue that counts.” – [Winston Churchill](https://selfsaid.30tools.com/winston-churchill-quotes)
97.  “Believe deep down in your heart that you’re destined to do great things.” – Joe Paterno
98.  “Create the highest, grandest vision possible for your life, because you become what you believe.” – Oprah Winfrey
99.  “Happiness is not something ready made. It comes from your own actions.” – Dalai Lama
100.  “If you can dream it, you can achieve it.” – Zig Ziglar
101.  “Today’s accomplishments were yesterday’s impossibilities.” – Robert H. Schuller
102.  “The only limit to our realization of tomorrow will be our doubts of today.” – Franklin D. Roosevelt
103.  “The future belongs to those who believe in the beauty of their dreams.” – Eleanor Roosevelt
104.  “Start where you are. Use what you have. Do what you can.” – Arthur Ashe
105.  “The only way to achieve the impossible is to believe it is possible.” – Charles Kingsleigh
106.  “Believe you can and you’re halfway there.” – Theodore Roosevelt
107.  “The difference between ordinary and extraordinary is that little extra.” – Jimmy Johnson
108.  “The key is to make it.” – Maya Angelou
109.  “Go confidently in the direction of your dreams. Live the life you have imagined.” – Henry David Thoreau
110.  “Today is a beautiful day and I will attract good things into my life.” – Unknown
111.  “Every morning starts a new page in your story. Make it a great one today!” – Doe Zantamata
112.  “Each day is a little life: every waking and rising a little birth, every fresh morning a little youth.” – Arthur Schopenhauer
113.  “Every day may not be good, but there’s something good in every day.” – Unknown
114.  “Life is too short to wake up with regrets. So, love the people who treat you right and forget about the ones who don’t.” – Unknown
115.  “Today is a good day to smile.” – Unknown
116.  “Rise up, start fresh, see the bright opportunity in each new day.” – Unknown
117.  “Each good morning we are born again, what we do today matters most.” – Buddha
118.  “Yesterday is gone, tomorrow is a mystery, today is a blessing.” – Unknown
119.  “Let your first hour set the theme of success and positive action that is certain to echo through your entire day.” – Unknown
120.  “Today is a beautiful day. Don’t let it get away.” – Unknown
121.  “Focus on the good and every day will be a good day.” – Unknown
122.  “Let today be the start of something new and wonderful.” – Unknown
123.  “Embrace the glorious mess that you are.” – Elizabeth Gilbert
124.  “Don’t watch the clock; do what it does. Keep going.” – Sam Levenson
125.  “Every day is a second chance.” – Unknown
126.  “Live life to the fullest and focus on the positive.” – Matt Cameron
127.  “Today is a new day. Expect great things!” – Unknown
128.  “Be so happy that when others look at you, they become happy too.” – Yogi Bhajan
129.  “Start each day with a positive thought and a grateful heart.” – Roy T. Bennett
130.  “Today, be the reason someone feels loved.” – Unknown
131.  “Today is a perfect day to start living your dreams.” – Unknown
132.  “Be the change you wish to see in the world.” – Mahatma Gandhi
133.  “Choose to shine.” – Unknown
134.  “Every day is a new beginning. Take a deep breath and start again.” – Unknown
135.  “Make each day your masterpiece.” – John Wooden
136.  “Happiness is not by chance, but by choice.” – Jim Rohn
137.  “Start the day with a smile and end it with champagne.” – Unknown
138.  “Every day is a new opportunity to shine. Take it and make it yours.” – Unknown
139.  “Let your most beautiful dream will become a reality.” – Unknown
140.  Good days start with coffee and a [positive mindset.”](https://selfsaid.30tools.com/always-keep-a-positive-mindset) – Unknown
141.  “Today is not just another day. It’s a new opportunity and a new beginning. Embrace it!” – Unknown
142.  “Today, be the best version of yourself.” – Unknown
143.  “Happiness is an inside job. Don’t assign anyone else that much power over your life.” – Mandy Hale
144.  “Today, let your light shine bright.” – Unknown
145.  “Life is a journey with problems to solve and lessons to learn but most of all… experiences to enjoy.” – Unknown
146.  “Positive mind. Positive vibes. Positive life.” – Unknown
147.  “Make today so beautiful that your yesterday is something you will smile about tomorrow.” – Unknown
148.  “Every day may not be good, but there is something good in every day.” – Unknown
149.  “Be strong because things will get better. It may be stormy now, but it never rains forever.” – Unknown
150.  “Every day is a new opportunity to change your life and be who you want to be.” – Demi Lovato
151.  “Smile at strangers, laugh at yourself, and know that you’re free to start over.” – Unknown
152.  “Today is a good day to have a good day!” – Unknown
153.  “Every day is a new beginning. Stay away from what might have been and look at what can be.” – Unknown
154.  “Life is too short to wake up with regrets. So love the people who treat you right and forget about the ones who don’t.” – Unknown
155.  “Good days are to be gathered like grapes, to be trodden and bottled into wine and kept for age to taste.” – John Fowles
156.  “Today is your opportunity to build the tomorrow you want.” – Ken Poirot
157.  Choose to be optimistic, it feels better.” – [Dalai Lama](https://selfsaid.30tools.com/inspirational-quotes-dalai-lama)
158.  “Believe you can and you’re halfway there.” – Theodore Roosevelt
159.  “The purpose of our lives is to be happy.” – Dalai Lama
160.  “A day without laughter is a day wasted.” – Charlie Chaplin
161.  “Make today your masterpiece.” – John Wooden
162.  “Make today so awesome yesterday gets jealous.” – Unknown
163.  “The only limit to our realization of tomorrow is our doubts of today.” – Franklin D. Roosevelt
164.  Let your unique awesomeness and [positive energy](https://selfsaid.30tools.com/morning-affirmations) inspire confidence in others.” – Unknown
165.  “Wherever you go, go with all your heart.” – Confucius
166.  “Today is a beautiful day. Don’t let it get away.” – Unknown
167.  “The sun himself is weak when he first rises and gathers strength and courage as the day gets on.” – Charles Dickens
168.  “Believe in yourself and all that you are. Know that there is something inside you that is greater than any obstacle.” – Christian D. Larson
169.  “Today is full of possibilities.” – Unknown
170.  “Every day is your opportunity to create a better you.” – Unknown
171.  “Believe in the magic of a new day.” – Unknown
172.  “Live each day as if your life had just begun.” – Johann Wolfgang Von Goethe
173.  “Breathe. Let go. And remind yourself that this very moment is the only one you know you have for sure.” – Oprah Winfrey
174.  “Do something today that your [future self will thank you for](https://selfsaid.30tools.com/future-self).” – Sean Patrick Flanery
175.  Each day provides its own gifts.” – [Marcus Aurelius](https://selfsaid.30tools.com/marcus-aurelius-quotes)
176.  “One small positive thought in the morning can change your whole day.” – Dalai Lama
177.  “Each morning brings a hidden blessing; a blessing which is unique to that day, and which cannot be kept or re-used. If we do not use this miracle today, it will be lost.” – [Paulo Coelho](https://selfsaid.30tools.com/20-inspiring-paulo-coelho-quotes)
178.  “Always believe that something wonderful is about to happen.” – Unknown
179.  “Make today another wonderful day.” – Unknown
180.  “Welcome this new day with a smile on your lips and a good thought in your heart.” – Unknown
181.  “Enjoy the little things today, for one day you may look back and realize they were the big things.” – Robert Brault
182.  “This day is all I have and these hours are now my eternity.” – Nellie Sachs
183.  “Start each day with a grateful heart.” – Unknown
184.  “Today, let us swim wildly, joyously in gratitude.” – Rumi
185.  “Welcome every morning with a smile. Look on the new day as another gift from your Creator, another golden opportunity to complete what you were unable to finish yesterday.” – Unknown
186.  “A good day is one where you can lay your head down at night with a smile on your face.” – Unknown
187.  “Today will never come again. Be a blessing. Be a friend. Encourage someone.” – Unknown
188.  “Today is a good day to be happy with what you have, which doesn’t mean you can’t desire new experiences and improvements. Life on earth, I think, is about appreciating (or at least humbly accepting) what is, while imagining and striving for what could be.” – Terri Guillemets
189.  “Every new day is a chance to change your life.” – Unknown
190.  “What you do today can improve all your tomorrows.” – Ralph Marston
191.  “Let your smile change the world, but don’t let the world change your smile.” – Unknown
192.  “Being happy or sad, gloomy or excited, moody or stable… are options that are presented to you every morning. You just have to make the right choice.” – Unknown
193.  “The only secret behind a good day is a good attitude.” – Unknown
194.  Embrace the day with confidence and a smile.” – Unknown
195.  “Let your joy burst forth like flowers in the spring.” – Unknown
196.  “You’re off to great places, today is your day. Your mountain is waiting, so get on your way.” – Dr. Seuss
197.  “A new day: Be open enough to see opportunities. Be wise enough to be grateful. Be courageous enough to be happy.” – Steve Maraboli
198.  “Every morning is a new opportunity to enrich our lives and to understand and expand the best in our life.” – Amit Ray
199.  “Every morning is a fresh beginning. Every day is the world made new.” – Dan Custer
200.  “Every day is a new adventure. Embrace it.” – Unknown
201.  “Approach the start of each day with something in mind and end the day with one word: DONE.” – Unknown
202.  “Make today ridiculously amazing.” – Unknown
203.  “Life is too short to wake up in the morning with regrets.” – Harvey Mackay
204.  “Every day is a new opportunity to be grateful, and enjoy the world, and improve it — in our own little ways.” – Terri Guillemets
205.  “May your day be filled with good thoughts, kind people, and happy moments.” – Unknown
206.  “Today, be mindful and kind and begin the day with a grateful heart.” – Unknown
207.  “Every day is a fresh start, wake up and live to the fullest.” – Unknown
208.  “Good morning! Remember: A person can succeed at almost anything for which they have unlimited enthusiasm.” – Charles M. Schwab
209.  “Today is a new day, don’t let the lows of yesterday prevent you from enjoying the highs of today.” – Unknown
210.  “Welcome every morning with a smile. Look on the new day as another special gift from your Creator, another golden opportunity.” – Og Mandino
211.  “Each new morning is a blank canvas… what masterpiece will you create today?” – Unknown
212.  “May your worries be light, and your joy be great.” – Unknown
213.  “Every morning starts a new page in your story. Make it a great one today.” – Doe Zantamata
214.  “A new day also means a new beginning. Forget about the past and have a fresh start.” – Unknown
215.  “Today is a beautiful day. Let it be full of hope and new opportunities.” – Unknown
216.  “Start your day with a positive attitude and plan to make the best of it.” – Unknown
217.  “Let your morning be the start of a great day.” – Unknown
218.  “Embrace the day’s opportunities and be thankful for every moment.” – Unknown

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fhave-a-good-day-quotes%2F)

[Pin3](https://pinterest.com/pin/create/button/?url=/have-a-good-day-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2FInspirational-Have-A-Good-Day-Quotes-PIN.jpg&description=Allow+these+218+inspirational+%27Have+A+Good+Day%27+Quotes+to+serve+as+a+reminder+of+life%27s+beauty+and+potential%2C+filling+your+day+with+positivity.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=218+Inspirational+%27Have+A+Good+Day%27+Quotes+to+Uplift+and+Inspire&url=https%3A%2F%2Fselfsaid.30tools.com%2Fhave-a-good-day-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fhave-a-good-day-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fhave-a-good-day-quotes%2F)

[More](#)

3 Shares

Source: https://selfsaid.30tools.com/have-a-good-day-quotes/
