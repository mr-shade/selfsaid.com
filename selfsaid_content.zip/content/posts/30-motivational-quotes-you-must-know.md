---
title: 30 Motivational Quotes Everyone Needs To Hear
date: '2024-09-11T12:24:19+02:00'
author: Seff Bray
description: >-
  These 30 epic motivational quotes will inspire you to achieve success,
  fortune, and happiness.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/motivational-quotes.webp'
original_url: 'https://selfsaid.30tools.com/30-motivational-quotes-you-must-know/'
---

![](https://seffsaid.com/wp-content/uploads/motivational-quotes.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

In need of some motivation? Well, aren’t we all! Read the list below of possibly the 30 greatest motivational quotes, adopt them into your life and you’ll soon be on your way to new found greatness. These epic quotes will help inspire you to achieve greater things.

*   “A little progress each day adds up to big results.” – Unknown
*   “No matter the situation, never let your emotions overpower your intelligence.” – Drake
*   “Falling down is an accident. Staying down is a choice.” – Unknown
*   “You miss 100% of the shots you don’t take.” – Wayne Gretzky
*   “Winners are not people who never fail, but people who never quit.” – Unknown
*   “You are the average of the five people you spend the most time with.” – Jim Rohn
*   “The best view comes after the hardest climb.” – Unknown
*   “Your mind is a powerful thing. When you fill it with positive thoughts, your life will start to change.” – Unknown
*   “Do something today that your future self will thank you for.” – Sean Patrick Flanery
*   “Don’t mistake movement for achievement. It’s easy to get faked out by being busy. The question is: Busy doing what?” – Jim Rohn
*   “If it doesn’t challenge you, it won’t change you.” – Fred DeVito
*   “Discipline is doing what you know needs to be done, even if you don’t want to do it.” – Unknown
*   “They told me I couldn’t. That’s why I did.” – Unknown
*   “You only fail when you stop trying.” – Unknown
*   “Don’t be afraid to fail. Be afraid not to try.” _–_ [Michael Jordan](https://selfsaid.30tools.com/michael-jordan-quotes)
*   “We learn from failure not from success.” – Bram Stoker
*   The secret to getting ahead is getting started.” – [Mark Twain](https://selfsaid.30tools.com/25-inspirational-mark-twain-quotes)
*   “When you know what you want, and you want it bad enough, you’ll find a way to get it.” – Jim Rohn
*   “The best way to predict the [future is to create it](https://selfsaid.30tools.com/how-to-create-an-exciting-future).” – Peter Drucker
*   “You are confined only by the walls you build yourself.” – Andrew Murphy
*   “One finds limits by pushing them.” – Herbert Simon.
*   “Time is more value than money. You can get more money, but you cannot get more time.” – Jim Rohn
*   “It’s not about having time, it’s about making time.” – Unknown
*   “Don’t wait for opportunity. Create it.” _–_ George Bernard Shaw
*   “Look in the mirror. That’s your competition.” – Unknown
*   “Don’t look back, you’re not going that way.” – Unknown
*   “If you are tired of starting over, stop giving up.” – Unknown
*   “I never lose. Either I win or I learn.” – Nelson Mandela
*   “The master has failed more times than the beginner has even tried.” _–_ Stephen McCranie

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2F30-motivational-quotes-you-must-know%2F)

[Pin2](https://pinterest.com/pin/create/button/?url=/30-motivational-quotes-you-must-know/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2Fmotivational-quotes-PIN.jpg&description=These+30+epic+motivational+quotes+will+inspire+you+to+achieve+success%2C+fortune%2C+and+happiness.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=30+Motivational+Quotes+Everyone+Needs+To+Hear&url=https%3A%2F%2Fselfsaid.30tools.com%2F30-motivational-quotes-you-must-know%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2F30-motivational-quotes-you-must-know%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2F30-motivational-quotes-you-must-know%2F)

[More](#)

2 Shares

Source: https://selfsaid.30tools.com/30-motivational-quotes-you-must-know/
