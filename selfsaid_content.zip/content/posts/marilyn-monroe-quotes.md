---
title: 50 Marilyn Monroe Quotes on Love and Life
date: '2024-04-28T16:24:58+02:00'
author: Seff Bray
description: >-
  Explore Marilyn Monroe's thoughts on love and life in these 50 revealing
  quotes.
tags: []
featured_image: 'https://seffsaid.com/wp-content/uploads/Marilyn-Monroe-Quotes.webp'
original_url: 'https://selfsaid.30tools.com/marilyn-monroe-quotes/'
---

![Marilyn Monroe](https://seffsaid.com/wp-content/uploads/Marilyn-Monroe-Quotes.webp)

**\> Feeling burnt out? Subscribe to my [**Everyday Self-Care Newsletter**](https://selfsaid.30tools.com/newsletter) for self-care tips and doable habits that support your well-being.**

Marilyn Monroe remains a captivating figure decades after her time, known not just for her glamour but also for her insightful reflections on life and love. Here are 50 quotes from Monroe that shed light on her personal philosophy and the wisdom she gained through her experiences. These quotes also offer a glimpse into her thoughts on [relationships](https://selfsaid.30tools.com/how-to-make-long-distance-relationships-work), self-worth, and navigating the challenges of everyday life.

1.  “Imperfection is beauty, madness is genius and it’s better to be absolutely ridiculous than absolutely boring.” – Marilyn Monroe
2.  “Give a girl the right shoes, and she can conquer the world.” – Marilyn Monroe
3.  “I don’t know who invented high heels, but all women owe him a lot.” – Marilyn Monroe
4.  “I am good, but not an angel. I do sin, but I am not the devil. I am just a small girl in a big world trying to find someone to love.” – Marilyn Monroe
5.  “Beneath the makeup and behind the smile, I am just a girl who wishes for the world.” – Marilyn Monroe
6.  “It’s better to be unhappy alone than unhappy with someone.” – Marilyn Monroe
7.  “Sometimes things fall apart so that better things can fall together.” – Marilyn Monroe
8.  “Fear is stupid. So are regrets.” – Marilyn Monroe
9.  “A wise girl kisses but doesn’t love, listens but doesn’t believe, and leaves before she is left.” – Marilyn Monroe
10.  “We are all of us stars, and we deserve to twinkle.” – Marilyn Monroe
11.  “The nicest thing for me is sleep, then at least I can dream.” – Marilyn Monroe
12.  “I am trying to find myself. Sometimes that’s not easy.” – Marilyn Monroe
13.  “I restore myself when I’m alone.” – Marilyn Monroe
14.  “Keep smiling, because life is a beautiful thing and there’s so much to smile about.” – Marilyn Monroe
15.  “In Hollywood, a girl’s virtue is much less important than her hairdo.” – Marilyn Monroe
16.  “A career is wonderful, but you can’t curl up with it on a cold night.” – Marilyn Monroe
17.  “All little girls should be told they are pretty, even if they aren’t.” – Marilyn Monroe
18.  “Just because you fail once doesn’t mean you’re gonna fail at everything.” – Marilyn Monroe
19.  “The real lover is the man who can thrill you by kissing your forehead or smiling into your eyes or just staring into space.” – Marilyn Monroe
20.  “I don’t mind living in a man’s world, as long as I can be a woman in it.” – Marilyn Monroe
21.  “[Success](https://selfsaid.30tools.com/why-some-people-are-more-successful-than-others) makes so many people hate you. I wish it wasn’t that way. It would be wonderful to enjoy success without seeing envy in the eyes of those around you.” – Marilyn Monroe
22.  “Ever notice how ‘What the hell’ is always the right decision to make?” – Marilyn Monroe
23.  “Women who seek to be equal with men lack ambition.” – Marilyn Monroe
24.  “I don’t want to make money. I just want to be wonderful.” – Marilyn Monroe
25.  “It’s all make believe, isn’t it?” – Marilyn Monroe
26.  “If I’m a star, then the people made me a star.” – Marilyn Monroe
27.  “[Dogs](https://selfsaid.30tools.com/7-amazing-benefits-of-adopting-a-dog) never bite me. Just humans.” – Marilyn Monroe
28.  “I don’t stop when I’m tired. I only stop when I’m done.” – Marilyn Monroe
29.  “Sex is a part of nature. I go along with nature.” – Marilyn Monroe
30.  “I learned to walk as a baby, and I haven’t had a lesson since.” – Marilyn Monroe
31.  “The trouble with censors is that they worry if a girl has cleavage. They ought to worry if she hasn’t any.” – Marilyn Monroe
32.  “I think that sexuality is only attractive when it’s natural and spontaneous.” – Marilyn Monroe
33.  “If I’d observed all the rules, I’d never have got anywhere.” – Marilyn Monroe
34.  “Happiness is the most important thing in the world, without it, you live a life of depression and fake smiles.” – Marilyn Monroe
35.  “When it comes down to it, I let them think what they want. If they care enough to bother with what I do, then I’m already better than them.” – Marilyn Monroe
36.  “I am not interested in money. I just want to be wonderful.” – Marilyn Monroe
37.  “I don’t know who invented high heels, but women owe him a lot.” – Marilyn Monroe
38.  “Your clothes should be tight enough to show you’re a woman but loose enough to show you’re a lady.” – Marilyn Monroe
39.  “A girl doesn’t need anyone who doesn’t need her.” – Marilyn Monroe
40.  “I think one of the basic reasons men make good friends is that they can make up their minds quickly.” – Marilyn Monroe
41.  “There’s only one sort of natural blonde on earth – albinos.” – Marilyn Monroe
42.  “It’s not true that I had nothing on. I had the radio on.” – Marilyn Monroe
43.  “The thing I want more than anything else? I want to be a housewife.” – Marilyn Monroe
44.  “I live to succeed, not to please you or anyone else.” – Marilyn Monroe
45.  “Being a sex symbol is a heavy load to carry, especially when one is tired, hurt, and bewildered.” – Marilyn Monroe
46.  “I never dropped anyone I believed in.” – Marilyn Monroe
47.  “Dreaming about being an actress, is more exciting than being one.” – Marilyn Monroe
48.  “I always felt insecure and in the way—but most of all I felt scared.” – Marilyn Monroe
49.  “You believe lies so you eventually learn to trust no one but yourself.” – Marilyn Monroe
50.  “I always have a full-length mirror next to the camera when I’m doing publicity stills. That way, I know how I look.” – Marilyn Monroe

Enjoyed these quotes? You can read more [quotes from famous people](https://selfsaid.30tools.com/quotes-by-famous-people) here!

[Share](https://www.facebook.com/share.php?u=https%3A%2F%2Fselfsaid.30tools.com%2Fmarilyn-monroe-quotes%2F)

[Pin7](https://pinterest.com/pin/create/button/?url=/marilyn-monroe-quotes/&media=https%3A%2F%2Fselfsaid.30tools.com%2Fwp-content%2Fuploads%2FMarilyn-Monroe-Quotes-PIN.jpg&description=Explore+Marilyn+Monroe%27s+thoughts+on+love+and+life+in+these+50+revealing+quotes.+via+%40SeffSaid)

[Tweet](https://twitter.com/intent/tweet?text=50+Marilyn+Monroe+Quotes+on+Love+and+Life&url=https%3A%2F%2Fselfsaid.30tools.com%2Fmarilyn-monroe-quotes%2F&via=SeffSaid)

[Reddit](https://www.reddit.com/submit?url=https%3A%2F%2Fselfsaid.30tools.com%2Fmarilyn-monroe-quotes%2F)

[Share](https://www.linkedin.com/cws/share?url=https%3A%2F%2Fselfsaid.30tools.com%2Fmarilyn-monroe-quotes%2F)

[More](#)

7 Shares

Source: https://selfsaid.30tools.com/marilyn-monroe-quotes/
